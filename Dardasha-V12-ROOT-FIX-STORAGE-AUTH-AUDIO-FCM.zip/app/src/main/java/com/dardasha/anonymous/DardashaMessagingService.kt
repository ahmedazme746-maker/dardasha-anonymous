package com.dardasha.anonymous

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class DardashaMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        val user = FirebaseAuth.getInstance().currentUser ?: return
        if (token.isBlank()) return
        FirebaseDatabase.getInstance("https://dardasha-anonymous-default-rtdb.firebaseio.com")
            .reference.child("users").child(user.uid).child("fcmToken").setValue(token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val notification = message.notification
        val title = notification?.title ?: message.data["title"] ?: "دردشة"
        val body = notification?.body ?: message.data["body"] ?: "لديك رسالة جديدة"
        val roomId = message.data["roomId"].orEmpty()
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (roomId.isNotBlank()) putExtra("roomId", roomId)
        }
        val pending = PendingIntent.getActivity(
            this,
            roomId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val channelId = "dardasha_messages_v3"
        val manager = getSystemService(NotificationManager::class.java)
        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(com.dardasha.anonymous.R.drawable.ic_dardasha)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pending)
        manager.notify((System.currentTimeMillis() and 0x7fffffff).toInt(), builder.build())
    }
}
