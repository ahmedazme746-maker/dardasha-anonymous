package com.dardasha.anonymous

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

private const val DB_URL = "https://dardasha-anonymous-default-rtdb.firebaseio.com"

data class Msg(val id: String, val sender: String, val text: String)

class MainActivity : ComponentActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseDatabase
    private var uid = ""
    private var room by mutableStateOf<String?>(null)
    private var searching by mutableStateOf(false)
    private val messages = mutableStateListOf<Msg>()
    private var waitRef: DatabaseReference? = null
    private var waitListener: ValueEventListener? = null
    private var msgRef: DatabaseReference? = null
    private var msgListener: ChildEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        db = FirebaseDatabase.getInstance(DB_URL)

        val user = auth.currentUser
        if (user != null) ready(user.uid) else auth.signInAnonymously()
            .addOnSuccessListener { ready(it.user!!.uid) }
            .addOnFailureListener {
                Toast.makeText(this, "تعذر الاتصال بـ Firebase", Toast.LENGTH_LONG).show()
            }

        setContent {
            MaterialTheme {
                if (uid.isEmpty()) Loading()
                else if (room != null) Chat(
                    uid, messages,
                    { send(it) },
                    { leave() }
                )
                else if (searching) Matching { cancelSearch() }
                else Home { findPerson() }
            }
        }
    }

    private fun ready(id: String) { uid = id }

    private fun findPerson() {
        searching = true
        val root = db.reference.child("waiting")
        waitRef = root.child(uid)
        waitRef!!.onDisconnect().removeValue()

        waitListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                s.child("roomId").getValue(String::class.java)?.let { openRoom(it) }
            }
            override fun onCancelled(e: DatabaseError) {}
        }
        waitRef!!.addValueEventListener(waitListener!!)

        root.runTransaction(object : Transaction.Handler {
            override fun doTransaction(d: MutableData): Transaction.Result {
                var other: String? = null
                for (c in d.children) {
                    if (c.key != uid && c.child("roomId").value == null) {
                        other = c.key
                        break
                    }
                }
                if (other == null) {
                    d.child(uid).value = mapOf("createdAt" to System.currentTimeMillis())
                } else {
                    val peer = other!!
                    val id = if (uid < peer) "$uid-$peer" else "$peer-$uid"
                    val oldTime = d.child(peer).child("createdAt").value
                        ?: System.currentTimeMillis()
                    d.child(uid).value = mapOf("createdAt" to System.currentTimeMillis(),
                        "roomId" to id, "peerId" to peer)
                    d.child(peer).value = mapOf("createdAt" to oldTime,
                        "roomId" to id, "peerId" to uid)
                }
                return Transaction.success(d)
            }
            override fun onComplete(e: DatabaseError?, ok: Boolean, s: DataSnapshot?) {
                if (e != null) runOnUiThread {
                    searching = false
                    Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
                }
            }
        })
    }

    private fun openRoom(id: String) {
        if (room == id) return
        room = id
        searching = false
        messages.clear()
        waitListener?.let { waitRef?.removeEventListener(it) }
        waitRef?.onDisconnect()?.cancel()
        waitRef?.removeValue()

        msgRef = db.reference.child("rooms").child(id).child("messages")
        msgListener = object : ChildEventListener {
            override fun onChildAdded(s: DataSnapshot, prev: String?) {
                val m = Msg(
                    s.key ?: return,
                    s.child("senderId").getValue(String::class.java).orEmpty(),
                    s.child("text").getValue(String::class.java).orEmpty()
                )
                if (messages.none { it.id == m.id }) messages.add(m)
            }
            override fun onChildChanged(s: DataSnapshot, p: String?) {}
            override fun onChildRemoved(s: DataSnapshot) { messages.removeAll { it.id == s.key } }
            override fun onChildMoved(s: DataSnapshot, p: String?) {}
            override fun onCancelled(e: DatabaseError) {}
        }
        msgRef!!.addChildEventListener(msgListener!!)
    }

    private fun send(text: String) {
        val clean = text.trim()
        val r = room ?: return
        if (clean.isEmpty()) return
        db.reference.child("rooms").child(r).child("messages").push().setValue(
            mapOf("senderId" to uid, "text" to clean, "timestamp" to ServerValue.TIMESTAMP)
        )
    }

    private fun cancelSearch() {
        waitListener?.let { waitRef?.removeEventListener(it) }
        waitRef?.onDisconnect()?.cancel()
        waitRef?.removeValue()
        searching = false
    }

    private fun leave() {
        msgListener?.let { msgRef?.removeEventListener(it) }
        room = null
        messages.clear()
    }

    override fun onDestroy() {
        waitListener?.let { waitRef?.removeEventListener(it) }
        msgListener?.let { msgRef?.removeEventListener(it) }
        super.onDestroy()
    }
}

@Composable fun Loading() {
    Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
}

@Composable fun Home(start: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("دردشة مع مجهول") }) }) { p ->
        Column(Modifier.fillMaxSize().padding(p).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Text("أهلاً بك في دردشة مع مجهول", style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text("تواصل مع أشخاص جدد بشكل مجهول.", textAlign = TextAlign.Center)
            Spacer(Modifier.height(28.dp))
            Button(start, Modifier.fillMaxWidth()) { Text("ابدأ محادثة عشوائية") }
        }
    }
}

@Composable fun Matching(cancel: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("البحث عن شخص") }) }) { p ->
        Column(Modifier.fillMaxSize().padding(p),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            CircularProgressIndicator()
            Spacer(Modifier.height(16.dp))
            Text("جاري البحث عن شخص للمحادثة...")
            Spacer(Modifier.height(20.dp))
            OutlinedButton(cancel) { Text("إلغاء البحث") }
        }
    }
}

@Composable fun Chat(uid: String, messages: List<Msg>, send: (String) -> Unit, leave: () -> Unit) {
    var text by remember { mutableStateOf("") }
    Scaffold(topBar = {
        TopAppBar(title = { Text("محادثة مجهولة") },
            actions = { TextButton(leave) { Text("خروج") } })
    }) { p ->
        Column(Modifier.fillMaxSize().padding(p).imePadding()) {
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages, key = { it.id }) { m ->
                    Row(Modifier.fillMaxWidth(),
                        horizontalArrangement = if (m.sender == uid) Arrangement.End else Arrangement.Start) {
                        Text(m.text, modifier = Modifier.padding(10.dp))
                    }
                }
            }
            HorizontalDivider()
            Row(Modifier.fillMaxWidth().padding(8.dp), Alignment.CenterVertically) {
                OutlinedTextField(text, { text = it }, Modifier.weight(1f),
                    placeholder = { Text("اكتب رسالتك...") }, singleLine = true)
                Spacer(Modifier.width(6.dp))
                Button({ send(text); text = "" }, enabled = text.isNotBlank()) {
                    Text("إرسال")
                }
            }
        }
    }
}
