Dardasha V12 / version 7.0

This is a full audited continuation, not a cosmetic patch.

Changes: default Firebase Storage instance; verified upload pipeline; detailed StorageException handling; cleanup of failed media uploads; safe recorder shutdown; safer profile save failure handling; new notification channel ID so Android does not keep an old silent channel; admin action failure handling; pending avatar cleanup on rejection; build version 7.0.

Owner UID remains exactly: wDMqt8jpP1gEJJtLuUMrTTaeU8q1

Required outside the APK: deploy database.rules.json and storage.rules, enable Firebase Storage, and for Google Sign-In enable Google + SHA-1 + download a new google-services.json containing an OAuth web client.
