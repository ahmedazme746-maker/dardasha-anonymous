const functions = require("firebase-functions/v1");
const admin = require("firebase-admin");

admin.initializeApp();

exports.sendDardashaMessageNotification = functions.database
  .ref("/rooms/{roomId}/messages/{messageId}")
  .onCreate(async (snapshot, context) => {
    const message = snapshot.val() || {};
    const senderId = String(message.senderId || "");
    const roomId = String(context.params.roomId || "");
    if (!senderId || !roomId) return null;

    // recipientId is written into every new message. This avoids a race where
    // the recipient has not yet written their own room-membership flag.
    let recipientId = String(message.recipientId || "");
    if (!recipientId || recipientId === senderId) {
      const roomSnap = await admin.database().ref(`rooms/${roomId}/members`).once("value");
      const members = roomSnap.val() || {};
      recipientId = Object.keys(members).find((id) => id !== senderId && members[id] === true) || "";
    }
    if (!recipientId) return null;

    const recipientSnap = await admin.database().ref(`users/${recipientId}`).once("value");
    const recipient = recipientSnap.val() || {};
    const token = String(recipient.fcmToken || "");
    if (!token) return null;

    const senderSnap = await admin.database().ref(`users/${senderId}`).once("value");
    const sender = senderSnap.val() || {};
    const senderName = String(sender.name || "مستخدم");

    let body = "لديك رسالة جديدة";
    if (message.type === "text") body = String(message.text || "لديك رسالة جديدة").slice(0, 120);
    else if (message.type === "image") body = "📷 أرسل لك صورة";
    else if (message.type === "audio") body = "🎤 أرسل لك تسجيلًا صوتيًا";

    try {
      await admin.messaging().send({
        token,
        notification: { title: senderName, body },
        data: {
          title: senderName,
          body,
          roomId,
          messageId: String(context.params.messageId),
          senderId,
          type: String(message.type || "text")
        },
        android: {
          priority: "high",
          notification: {
            channelId: "dardasha_messages_v3",
            sound: "default"
          }
        }
      });
    } catch (error) {
      functions.logger.error("FCM send failed", { error: error?.message, recipientId, roomId });
    }
    return null;
  });
