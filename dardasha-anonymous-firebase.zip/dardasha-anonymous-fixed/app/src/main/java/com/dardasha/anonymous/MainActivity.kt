package com.dardasha.anonymous

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DardashaApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DardashaApp() {
    var screen by remember { mutableStateOf("home") }
    var connectionStatus by remember { mutableStateOf("جاري الاتصال بالخادم...") }

    LaunchedEffect(Unit) {
        val auth = FirebaseAuth.getInstance()
        val database = FirebaseDatabase.getInstance("https://dardasha-anonymous-default-rtdb.firebaseio.com")
        val finish = { uid: String ->
            database.reference.child("users").child(uid).child("online").setValue(true)
                .addOnSuccessListener { connectionStatus = "متصل بالخادم ✓" }
                .addOnFailureListener { connectionStatus = "تم تسجيل الدخول، تعذر حفظ الحالة" }
        }
        if (auth.currentUser != null) finish(auth.currentUser!!.uid)
        else auth.signInAnonymously()
            .addOnSuccessListener { finish(it.user!!.uid) }
            .addOnFailureListener { connectionStatus = "تعذر الاتصال بالخادم" }
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("دردشة مع مجهول") }) },
            bottomBar = {
                NavigationBar {
                    listOf("الرئيسية", "المحادثات", "حسابي").forEach { item ->
                        NavigationBarItem(
                            selected = screen == item,
                            onClick = { screen = item },
                            icon = {},
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { pad ->
            when (screen) {
                "المحادثات" -> ChatList(Modifier.padding(pad))
                "حسابي" -> Profile(Modifier.padding(pad))
                else -> Home(Modifier.padding(pad), connectionStatus) { screen = "المحادثات" }
            }
        }
    }
}

@Composable
fun Home(modifier: Modifier, status: String, onStart: () -> Unit) {
    Column(
        modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("أهلاً بك في دردشة مع مجهول", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text("تواصل مع أشخاص جدد بشكل مجهول.")
        Spacer(Modifier.height(12.dp))
        Text(status)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onStart) { Text("ابدأ محادثة عشوائية") }
    }
}

@Composable
fun ChatList(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp)) {
        Text("المحادثات", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text("سيتم تفعيل المطابقة والرسائل في الخطوة التالية.")
    }
}

@Composable
fun Profile(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp)) {
        Text("حسابي", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text("المستخدم المجهول")
        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = {}) { Text("إبلاغ عن مشكلة") }
        OutlinedButton(onClick = {}) { Text("المستخدمون المحظورون") }
    }
}
