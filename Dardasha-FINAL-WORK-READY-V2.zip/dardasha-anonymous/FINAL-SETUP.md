# Dardasha Anonymous — Final Work Package

## Firebase owner
- Owner UID: `wDMqt8jpP1gEJJtLuUMrTTaeU8q1`
- Email/Password authentication must remain enabled.

## Included final behavior
- Email/password login and account creation.
- Anonymous guest login.
- Dark purple/pink UI.
- Random matching.
- Messages, image messages, and voice messages.
- Image messages are hidden by the app after 3 minutes; server-side scheduled storage deletion is not included.
- Profile image approval workflow.
- Verification badge.
- Admin dashboard with user moderation and reports.
- Firebase presence using `.info/connected` and server-side `onDisconnect`.
- Manual "show me in Active Now" switch in Profile. When disabled, the account is written as offline and is excluded from Active Now.
- Admin is pinned above other online users.
- Other online users are ordered by latest login time.
- Fixed admin identity; no first-user-admin behavior.

## Build
The GitHub Actions workflow uses Java 17, Gradle 8.13, Android SDK 36, and builds a debug APK.

## Important
The source package has been statically reviewed and the known owner/presence/security issues were updated. The final APK build still needs to be executed by GitHub Actions to verify the Android toolchain in the target environment.
