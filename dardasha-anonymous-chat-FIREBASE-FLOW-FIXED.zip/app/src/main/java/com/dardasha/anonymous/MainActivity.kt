@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.dardasha.anonymous

import android.os.Bundle
import android.widget.Toast
import com.google.firebase.database.Logger
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.ServerValue
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener

private const val DB_URL = "https://dardasha-anonymous-default-rtdb.firebaseio.com"
private const val MAX_MESSAGE_LENGTH = 1000

data class Msg(
    val id: String,
    val sender: String,
    val text: String,
    val timestamp: Long = 0L
)

class MainActivity : ComponentActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseDatabase

    private var uid by mutableStateOf("")
    private var room by mutableStateOf<String?>(null)
    private var searching by mutableStateOf(false)
    private var busy by mutableStateOf(false)
    private var errorText by mutableStateOf<String?>(null)

    private val messages = mutableStateListOf<Msg>()

    private var waitRef: DatabaseReference? = null
    private var waitListener: ValueEventListener? = null
    private var msgRef: DatabaseReference? = null
    private var msgListener: ChildEventListener? = null
    private var connectionRef: DatabaseReference? = null
    private var connectionListener: ValueEventListener? = null
    private var connected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        auth = FirebaseAuth.getInstance()
        db = FirebaseDatabase.getInstance(DB_URL)
        db.setPersistenceEnabled(true)
        db.setLogLevel(Logger.Level.ERROR)

        watchConnection()
        authenticate()

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppContent()
                }
            }
        }
    }


    private fun watchConnection() {
        val ref = db.reference.child(".info").child("connected")
        connectionRef = ref
        connectionListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                connected = snapshot.getValue(Boolean::class.java) == true
                if (connected && errorText == "لا يوجد اتصال بقاعدة البيانات") {
                    errorText = null
                }
            }

            override fun onCancelled(error: DatabaseError) {
                connected = false
            }
        }
        ref.addValueEventListener(connectionListener!!)
    }

    private fun authenticate() {
        val current = auth.currentUser
        if (current != null) {
            uid = current.uid
            return
        }

        auth.signInAnonymously()
            .addOnSuccessListener { result ->
                val userId = result.user?.uid
                if (userId.isNullOrBlank()) {
                    showError("تعذر إنشاء الحساب المجهول")
                } else {
                    uid = userId
                    errorText = null
                }
            }
            .addOnFailureListener { e ->
                showError("تعذر الاتصال بـ Firebase: ${e.message ?: "خطأ غير معروف"}")
            }
    }

    @Composable
    private fun AppContent() {
        when {
            uid.isBlank() -> LoadingScreen()
            room != null -> ChatScreen()
            searching -> MatchingScreen()
            else -> HomeScreen()
        }
    }

    @Composable
    private fun LoadingScreen() {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(Modifier.height(16.dp))
                Text("جاري الاتصال...")
                errorText?.let {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = it,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            }
        }
    }

    @Composable
    private fun HomeScreen() {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("دردشة مع مجهول") })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "أهلاً بك في دردشة مع مجهول",
                    style = MaterialTheme.typography.headlineSmall,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    "تواصل مع أشخاص جدد بشكل مجهول.",
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(28.dp))
                Button(
                    onClick = { startMatching() },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("ابدأ محادثة عشوائية")
                }
                errorText?.let {
                    Spacer(Modifier.height(16.dp))
                    Text(
                        text = it,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }

    @Composable
    private fun MatchingScreen() {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("البحث عن شخص") })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator()
                Spacer(Modifier.height(16.dp))
                Text("جاري البحث عن شخص للمحادثة...")
                Spacer(Modifier.height(20.dp))
                OutlinedButton(onClick = { cancelSearch() }) {
                    Text("إلغاء البحث")
                }
            }
        }
    }

    @Composable
    private fun ChatScreen() {
        val currentRoom = room ?: return
        var text by remember(currentRoom) { mutableStateOf("") }
        val listState = rememberLazyListState()

        LaunchedEffect(messages.size) {
            if (messages.isNotEmpty()) {
                listState.animateScrollToItem(messages.lastIndex)
            }
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("محادثة مجهولة") },
                    actions = {
                        TextButton(onClick = { leaveRoom() }) {
                            Text("خروج")
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .imePadding()
            ) {
                errorText?.let {
                    Text(
                        text = it,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(
                        items = messages,
                        key = { it.id }
                    ) { message ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (message.sender == uid) {
                                Arrangement.End
                            } else {
                                Arrangement.Start
                            }
                        ) {
                            Text(
                                text = message.text,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }

                HorizontalDivider()

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = text,
                        onValueChange = {
                            if (it.length <= MAX_MESSAGE_LENGTH) text = it
                        },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("اكتب رسالتك...") },
                        singleLine = true,
                        enabled = !busy
                    )
                    Spacer(Modifier.width(6.dp))
                    Button(
                        onClick = {
                            val value = text.trim()
                            if (value.isNotEmpty() && !busy) {
                                sendMessage(value)
                                text = ""
                            }
                        },
                        enabled = text.trim().isNotEmpty() && !busy
                    ) {
                        Text("إرسال")
                    }
                }
            }
        }
    }

    private fun startMatching() {
        if (uid.isBlank() || searching || busy) return

        if (!connected) {
            errorText = "لا يوجد اتصال بقاعدة البيانات. حاول مرة أخرى."
            return
        }

        errorText = null
        busy = true
        searching = true
        cleanupWaiting(removeValue = true)

        val waitingRoot = db.reference.child("waiting")
        val myRef = waitingRoot.child(uid)
        waitRef = myRef

        myRef.onDisconnect().removeValue()

        waitListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val roomId = snapshot.child("roomId").getValue(String::class.java)
                if (!roomId.isNullOrBlank()) {
                    openRoom(roomId)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                failSearch("تعذر البحث: ${error.message}")
            }
        }

        myRef.addValueEventListener(waitListener!!)

        waitingRoot.runTransaction(object : Transaction.Handler {
            override fun doTransaction(data: MutableData): Transaction.Result {
                var peerId: String? = null
                var peerCreatedAt = 0L
                val now = System.currentTimeMillis()
                val staleAfterMs = 2 * 60 * 1000L

                for (child in data.children) {
                    val candidate = child.key ?: continue
                    if (candidate == uid) continue
                    if (child.child("roomId").value != null) continue

                    val created = child.child("createdAt").getValue(Long::class.java) ?: 0L
                    if (created > 0L && now - created > staleAfterMs) {
                        child.value = null
                        continue
                    }

                    peerId = candidate
                    peerCreatedAt = if (created > 0L) created else now
                    break
                }

                if (peerId == null) {
                    data.child(uid).value = mapOf(
                        "createdAt" to now
                    )
                } else {
                    val peer = peerId!!
                    val roomId = if (uid < peer) {
                        "$uid-$peer"
                    } else {
                        "$peer-$uid"
                    }

                    data.child(uid).value = mapOf(
                        "createdAt" to now,
                        "roomId" to roomId,
                        "peerId" to peer
                    )
                    data.child(peer).value = mapOf(
                        "createdAt" to peerCreatedAt,
                        "roomId" to roomId,
                        "peerId" to uid
                    )
                }

                return Transaction.success(data)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                snapshot: DataSnapshot?
            ) {
                runOnUiThread {
                    busy = false
                    if (error != null || !committed) {
                        failSearch(error?.message ?: "تعذر بدء البحث")
                    }
                }
            }
        })
    }

    private fun openRoom(roomId: String) {
        if (room == roomId) return

        cleanupWaiting(removeValue = true)
        cleanupMessages()

        errorText = null
        busy = false
        searching = false
        room = roomId
        messages.clear()

        val reference = db.reference
            .child("rooms")
            .child(roomId)
            .child("messages")

        msgRef = reference

        msgListener = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val id = snapshot.key ?: return
                val sender = snapshot.child("senderId")
                    .getValue(String::class.java)
                    .orEmpty()
                val text = snapshot.child("text")
                    .getValue(String::class.java)
                    .orEmpty()
                val timestamp = snapshot.child("timestamp")
                    .getValue(Long::class.java)
                    ?: 0L

                if (text.isBlank()) return
                if (messages.none { it.id == id }) {
                    messages.add(Msg(id, sender, text, timestamp))
                    messages.sortBy { it.timestamp }
                }
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) = Unit

            override fun onChildRemoved(snapshot: DataSnapshot) {
                val id = snapshot.key ?: return
                messages.removeAll { it.id == id }
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) = Unit

            override fun onCancelled(error: DatabaseError) {
                errorText = "تعذر تحميل الرسائل: ${error.message}"
            }
        }

        reference.addChildEventListener(msgListener!!)
    }

    private fun sendMessage(text: String) {
        val currentRoom = room ?: return
        val currentUid = uid
        if (currentUid.isBlank() || text.isBlank() || busy) return

        busy = true
        errorText = null

        val reference = db.reference
            .child("rooms")
            .child(currentRoom)
            .child("messages")
            .push()

        val data = mapOf<String, Any>(
            "senderId" to currentUid,
            "text" to text.take(MAX_MESSAGE_LENGTH),
            "timestamp" to ServerValue.TIMESTAMP
        )

        reference.setValue(data)
            .addOnSuccessListener {
                busy = false
            }
            .addOnFailureListener { e ->
                busy = false
                errorText = "تعذر إرسال الرسالة: ${e.message ?: "خطأ غير معروف"}"
            }
    }

    private fun cancelSearch() {
        cleanupWaiting(removeValue = true)
        searching = false
        busy = false
        errorText = null
    }

    private fun leaveRoom() {
        cleanupMessages()
        cleanupWaiting(removeValue = true)
        room = null
        searching = false
        busy = false
        errorText = null
        messages.clear()
    }

    private fun cleanupWaiting(removeValue: Boolean) {
        waitListener?.let { listener ->
            waitRef?.removeEventListener(listener)
        }
        waitListener = null

        waitRef?.onDisconnect()?.cancel()

        if (removeValue) {
            waitRef?.removeValue()
        }

        waitRef = null
    }

    private fun cleanupMessages() {
        msgListener?.let { listener ->
            msgRef?.removeEventListener(listener)
        }
        msgListener = null
        msgRef = null
    }

    private fun failSearch(message: String) {
        cleanupWaiting(removeValue = true)
        searching = false
        busy = false
        errorText = message
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun showError(message: String) {
        busy = false
        searching = false
        errorText = message
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        cleanupWaiting(removeValue = true)
        cleanupMessages()

        connectionListener?.let { listener ->
            connectionRef?.removeEventListener(listener)
        }
        connectionListener = null
        connectionRef = null

        super.onDestroy()
    }
}
