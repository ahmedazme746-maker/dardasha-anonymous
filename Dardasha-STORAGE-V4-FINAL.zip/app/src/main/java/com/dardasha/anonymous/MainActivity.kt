@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.dardasha.anonymous

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.app.NotificationChannel
import android.app.NotificationManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.text.ClickableText
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.FirebaseApp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID
import java.util.Locale

private const val DB_URL = "https://dardasha-anonymous-default-rtdb.firebaseio.com"
private const val OWNER_UID = "wDMqt8jpP1gEJJtLuUMrTTaeU8q1"
private const val MAX_MESSAGE_LENGTH = 1000
private const val IMAGE_LIFETIME_MS = 3 * 60 * 1000L
private const val MESSAGE_RETENTION_MS = 30L * 24 * 60 * 60 * 1000L
private const val HEARTBEAT_MS = 30_000L
private const val NAME_VIOLATION_REPLACEMENT = "تم مسح الاسم للمخالفة"
private const val TYPING_TIMEOUT_MS = 1800L
private const val NOTIFICATION_CHANNEL_ID = "dardasha_messages_v2"
private const val NOTIFICATION_PERMISSION_REQUEST = 3001
private const val BUILD_STAMP = "DARDASHA-MAIN-BUILD-V4-STORAGE-FIX"

private val FORBIDDEN_NAME_WORDS = setOf(
    "احا", "اها", "أحا", "أحا", "نيك", "نايك", "منيك", "منيكه", "منيكه",
    "جنس", "فحل", "شرموطه", "شرموطة", "شراميط", "كس", "طيز", "زب", "قحبه", "قحبة",
    "عرص", "خول", "متناك", "منايك", "سكس", "sex", "fuck", "shit", "dick", "pussy",
    "whore", "bitch", "slut", "زبي", "زبى", "زبر", "كسك", "كسها", "كس امك", "كسامي", "امك", "ابن عرص", "ابن متناك", "قحبه", "قحبة", "عاهرة", "عاهره", "دعاره", "دعارة", "نيكك", "ناكك", "ينك", "مكس", "مكسك"
)

private fun normalizeNameForFilter(value: String): String {
    return value.lowercase(Locale.getDefault())
        .replace(Regex("[\u064B-\u065F\u0670]"), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه').replace("ـ", "")
        .replace(Regex("[^\\p{L}\\p{N}]"), "")
        .replace(Regex("(.)\\1{2,}"), "$1$1")
}

private fun sanitizeDisplayName(value: String): String {
    val trimmed = value.trim().take(32)
    if (trimmed.isBlank()) return NAME_VIOLATION_REPLACEMENT
    val normalized = normalizeNameForFilter(trimmed)
    val bad = FORBIDDEN_NAME_WORDS.any { normalizeNameForFilter(it) in normalized }
    return if (bad) NAME_VIOLATION_REPLACEMENT else trimmed
}


private val Bg = Color(0xFF070617)
private val Panel = Color(0xFF111128)
private val Panel2 = Color(0xFF171637)
private val Purple = Color(0xFF8B35FF)
private val Violet = Color(0xFF6A22E8)
private val Pink = Color(0xFFFF4FD8)
private val TextMain = Color(0xFFF7F3FF)
private val TextMuted = Color(0xFFB9B2D0)
private val Green = Color(0xFF20E070)
private val Blue = Color(0xFF4EA7FF)
private val Red = Color(0xFFFF5577)

private val MainGradient = Brush.horizontalGradient(listOf(Purple, Pink))
private val SoftGradient = Brush.linearGradient(listOf(Color(0xFF32136B), Color(0xFF14142E)))

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val gender: String = "",
    val avatarUrl: String = "",
    val avatarPendingUrl: String = "",
    val avatarPending: Boolean = false,
    val avatarStoragePath: String = "",
    val avatarPendingStoragePath: String = "",
    val verified: Boolean = false,
    val admin: Boolean = false,
    val banned: Boolean = false,
    val online: Boolean = false,
    val joinedAt: Long = 0L,
    val lastSeen: Long = 0L,
    val manualOffline: Boolean = false
)

data class Msg(
    val id: String,
    val senderId: String,
    val type: String,
    val text: String,
    val imageUrl: String,
    val audioUrl: String,
    val storagePath: String,
    val timestamp: Long,
    val expiresAt: Long,
    val deliveredAt: Long,
    val readAt: Long
)

data class ChatPreview(
    val roomId: String,
    val peerId: String,
    val peerName: String,
    val peerVerified: Boolean,
    val peerAvatar: String,
    val peerAvatarPath: String,
    val lastMessage: String,
    val updatedAt: Long,
    val unreadCount: Int = 0
)

data class ReportItem(
    val id: String,
    val reporterId: String,
    val reportedId: String,
    val reason: String,
    val createdAt: Long
)

class MainActivity : ComponentActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseDatabase
    private lateinit var storage: FirebaseStorage

    private var uid by mutableStateOf("")
    private var profile by mutableStateOf<UserProfile?>(null)
    private var screen by mutableStateOf("login")
    private var selectedTab by mutableStateOf(0)
    private var loading by mutableStateOf(false)
    private var errorText by mutableStateOf<String?>(null)
    private var isRecording by mutableStateOf(false)
    private var now by mutableStateOf(System.currentTimeMillis())
    private var isBlocked by mutableStateOf(false)
    private var iBlockedPeer by mutableStateOf(false)

    private val messages = mutableStateListOf<Msg>()
    private val deletedMessageIds = mutableStateListOf<String>()
    private val onlineUsers = mutableStateListOf<UserProfile>()
    private val chats = mutableStateListOf<ChatPreview>()
    private var currentRoom by mutableStateOf<String?>(null)
    private var currentPeer by mutableStateOf<UserProfile?>(null)

    private var usersListener: ValueEventListener? = null
    private var chatsListener: ValueEventListener? = null
    private var messagesListener: ChildEventListener? = null
    private var messageDeletesListener: ValueEventListener? = null
    private var typingListener: ValueEventListener? = null
    private var currentRoomRef: DatabaseReference? = null
    private var waitingListener: ValueEventListener? = null
    private var mediaRecorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private var mediaPlayer: MediaPlayer? = null
    private val heartbeatHandler = Handler(Looper.getMainLooper())
    private var appInForeground = false
    private var unreadInitialized = false
    private var lastUnreadTotal = 0
    private var messageListenerPrimed = false
    private var peerTyping by mutableStateOf(false)
    private val typingHandler = Handler(Looper.getMainLooper())
    private var typingRunnable: Runnable? = null

    private val heartbeat = object : Runnable {
        override fun run() {
            if (appInForeground && uid.isNotBlank() && profile?.manualOffline != true) {
                db.reference.child("users").child(uid).updateChildren(
                    mapOf("online" to true, "lastSeen" to ServerValue.TIMESTAMP)
                )
            }
            heartbeatHandler.postDelayed(this, HEARTBEAT_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        db = FirebaseDatabase.getInstance(DB_URL)
        // Always use the Firebase default Storage bucket from the initialized
        // FirebaseApp. Do not reconstruct a gs:// URL in app code; that can
        // point to a different bucket after a Firebase project migration.
        storage = FirebaseStorage.getInstance()
        now = System.currentTimeMillis()
        createNotificationChannel()

        val current = auth.currentUser
        if (current != null) {
            uid = current.uid
            loadProfileOrSetup()
        }

        setContent {
            DardashaTheme { Surface(Modifier.fillMaxSize(), color = Bg) { App() } }
        }

        heartbeatHandler.post(heartbeat)
    }

    override fun onStart() {
        super.onStart()
        appInForeground = true
        if (uid.isNotBlank() && profile?.manualOffline != true) setPresence(true)
    }

    override fun onStop() {
        appInForeground = false
        if (uid.isNotBlank()) setPresence(false)
        super.onStop()
    }

    override fun onDestroy() {
        heartbeatHandler.removeCallbacks(heartbeat)
        stopRecordingSilently()
        mediaPlayer?.release()
        mediaPlayer = null
        super.onDestroy()
    }

    @Composable
    private fun App() {
        BackHandler(enabled = screen != "login") {
            when (screen) {
                "chat" -> closeRoom()
                "password", "settings", "edit", "admin" -> screen = "main"
                "guest", "register" -> screen = "login"
                "main" -> if (selectedTab != 0) selectedTab = 0 else Unit
                else -> screen = "login"
            }
        }
        LaunchedEffect(Unit) {
            while (true) {
                now = System.currentTimeMillis()
                delay(1_000)
            }
        }
        when (screen) {
            "login" -> LoginScreen()
            "guest" -> GuestScreen()
            "register" -> RegisterScreen()
            "main" -> MainScreen()
            "chat" -> ChatScreen()
            "admin" -> AdminScreen()
            "edit" -> EditProfileScreen()
            "password" -> ChangePasswordScreen()
            "settings" -> SettingsScreen()
            else -> LoginScreen()
        }
    }

    @Composable
    private fun DardashaLogo(size: Int = 92) {
        Box(
            Modifier.size(size.dp).shadow(16.dp, CircleShape).background(MainGradient, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.FavoriteBorder, null, tint = Color.White, modifier = Modifier.size((size * .55).dp))
        }
    }

    @Composable
    private fun ScreenBackground(content: @Composable BoxScope.() -> Unit) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF09071A), Color(0xFF070617), Color(0xFF0D0820)))
            ),
            content = content
        )
    }

    @Composable
    private fun GradientButton(
        text: String,
        onClick: () -> Unit,
        modifier: Modifier = Modifier,
        enabled: Boolean = true,
        icon: @Composable (() -> Unit)? = null
    ) {
        Box(
            modifier
                .height(54.dp)
                .clip(RoundedCornerShape(17.dp))
                .background(if (enabled) MainGradient else Brush.linearGradient(listOf(Color.DarkGray, Color.Gray)))
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) { icon(); Spacer(Modifier.width(9.dp)) }
                Text(text, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }

    @Composable
    private fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
        Column(
            modifier
                .clip(RoundedCornerShape(22.dp))
                .background(SoftGradient)
                .border(1.dp, Color(0xFF3C2A69), RoundedCornerShape(22.dp))
                .padding(18.dp),
            content = content
        )
    }

    @Composable
    private fun AuthHeader(title: String, subtitle: String) {
        DardashaLogo()
        Spacer(Modifier.height(18.dp))
        Text(title, style = MaterialTheme.typography.headlineLarge, color = TextMain, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color = TextMuted, textAlign = TextAlign.Center)
    }

    @Composable
    private fun AuthField(value: String, onValueChange: (String) -> Unit, label: String, icon: @Composable () -> Unit, password: Boolean = false) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text(label) },
            leadingIcon = icon,
            visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Panel2,
                unfocusedContainerColor = Panel,
                focusedBorderColor = Pink,
                unfocusedBorderColor = Color(0xFF363052),
                focusedLabelColor = Pink,
                unfocusedLabelColor = TextMuted,
                focusedTextColor = TextMain,
                unfocusedTextColor = TextMain,
                cursorColor = Pink,
                focusedLeadingIconColor = Pink,
                unfocusedLeadingIconColor = TextMuted
            )
        )
    }

    @Composable
    private fun LoginScreen() {
        var email by remember { mutableStateOf("") }
        var password by remember { mutableStateOf("") }
        ScreenBackground {
            Column(
                Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                AuthHeader("دردشة", "تواصل مع أشخاص جدد")
                Spacer(Modifier.height(25.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    AuthField(email, { email = it }, "البريد الإلكتروني", { Icon(Icons.Outlined.Email, null) })
                    Spacer(Modifier.height(12.dp))
                    AuthField(password, { password = it }, "كلمة المرور", { Icon(Icons.Outlined.Lock, null) }, true)
                    TextButton({ resetPassword(email) }, Modifier.align(Alignment.End)) { Text("نسيت كلمة المرور؟", color = TextMuted) }
                    GradientButton("تسجيل الدخول", { login(email, password) }, Modifier.fillMaxWidth(), !loading && email.isNotBlank() && password.isNotBlank(), { Icon(Icons.Default.Login, null) })
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        HorizontalDivider(Modifier.weight(1f), color = Color(0xFF3A3355)); Text("  أو  ", color = TextMuted); HorizontalDivider(Modifier.weight(1f), color = Color(0xFF3A3355))
                    }
                    Spacer(Modifier.height(14.dp))
                    OutlinedButton({ signInWithGoogle() }, Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain), enabled = !loading) {
                        Text("G  المتابعة عبر Google", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton({ screen = "guest" }, Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain)) { Text("دخول كزائر") }
                    TextButton({ screen = "register" }, Modifier.fillMaxWidth()) { Text("ليس لديك حساب؟ إنشاء حساب", color = Pink, fontWeight = FontWeight.Bold) }
                }
                ErrorText()
            }
        }
    }

    @Composable
    private fun GuestScreen() {
        var name by remember { mutableStateOf("") }
        var gender by remember { mutableStateOf("") }
        ScreenBackground {
            Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                AuthHeader("دخول كزائر", "ابدأ الدردشة الآن بدون تسجيل")
                Spacer(Modifier.height(24.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    AuthField(name, { name = it }, "الاسم المستعار", { Icon(Icons.Outlined.Person, null) })
                    Spacer(Modifier.height(15.dp))
                    Text("اختر الجنس (لا يمكن تغييره لاحقًا)", color = TextMuted, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(10.dp))
                    GenderChoice(gender) { gender = it }
                    Spacer(Modifier.height(18.dp))
                    GradientButton("دخول كزائر", { createGuestProfile(name, gender) }, Modifier.fillMaxWidth(), !loading && name.trim().isNotEmpty() && gender.isNotBlank(), { Icon(Icons.Default.Login, null) })
                    TextButton({ screen = "login" }, Modifier.fillMaxWidth()) { Text("رجوع", color = TextMuted) }
                }
                ErrorText()
            }
        }
    }

    @Composable
    private fun RegisterScreen() {
        var name by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var password by remember { mutableStateOf("") }
        var gender by remember { mutableStateOf("") }
        ScreenBackground {
            Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                AuthHeader("إنشاء حساب", "انضم إلينا وكن جزءًا من مجتمع الدردشة")
                Spacer(Modifier.height(20.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    AuthField(name, { name = it }, "الاسم المستعار", { Icon(Icons.Outlined.Person, null) })
                    Spacer(Modifier.height(10.dp))
                    AuthField(email, { email = it }, "البريد الإلكتروني", { Icon(Icons.Outlined.Email, null) })
                    Spacer(Modifier.height(10.dp))
                    AuthField(password, { password = it }, "كلمة المرور", { Icon(Icons.Outlined.Lock, null) }, true)
                    Spacer(Modifier.height(15.dp))
                    Text("اختر الجنس (لا يمكن تغييره لاحقًا)", color = TextMuted, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(10.dp))
                    GenderChoice(gender) { gender = it }
                    Spacer(Modifier.height(18.dp))
                    GradientButton("إنشاء الحساب", { register(name, email, password, gender) }, Modifier.fillMaxWidth(), !loading && name.trim().isNotEmpty() && email.contains("@") && password.length >= 6 && gender.isNotBlank(), { Icon(Icons.Default.PersonAdd, null) })
                    TextButton({ screen = "login" }, Modifier.fillMaxWidth()) { Text("لديك حساب؟ تسجيل الدخول", color = Pink) }
                }
                ErrorText()
            }
        }
    }

    @Composable
    private fun MainScreen() {
        val tabs = listOf("عشوائي", "الرسائل", "نشط الآن", "ملفي")
        val icons = listOf(Icons.Outlined.Shuffle, Icons.Outlined.Email, Icons.Outlined.People, Icons.Outlined.Person)
        Scaffold(
            containerColor = Bg,
            topBar = {
                Row(Modifier.fillMaxWidth().background(Color(0xFF0A091B)).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).background(MainGradient, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.FavoriteBorder, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
                        Spacer(Modifier.width(10.dp)); Text("دردشة", color = TextMain, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                    }
                    if (profile?.admin == true) IconButton({ screen = "admin" }) { Icon(Icons.Outlined.AdminPanelSettings, "الإدارة", tint = Pink) }
                    IconButton({ loadProfileOrSetup() }) { Icon(Icons.Default.Refresh, "تحديث", tint = TextMain) }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0D0B20)) {
                    tabs.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = selectedTab == i,
                            onClick = { selectedTab = i },
                            icon = { Icon(icons[i], null) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Pink, selectedTextColor = Pink, indicatorColor = Color(0xFF2A1549), unselectedIconColor = TextMuted, unselectedTextColor = TextMuted)
                        )
                    }
                }
            }
        ) { p ->
            Box(Modifier.fillMaxSize().padding(p)) {
                when (selectedTab) { 0 -> RandomScreen(); 1 -> MessagesScreen(); 2 -> OnlineScreen(); 3 -> ProfileScreen() }
            }
        }
    }

    @Composable
    private fun RandomScreen() {
        ScreenBackground {
            Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.offset((-18).dp, 8.dp).size(90.dp).background(Color(0xFF6A25E8), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.ChatBubble, null, tint = Color.White, modifier = Modifier.size(48.dp)) }
                    Box(Modifier.offset(28.dp, (-8).dp).size(86.dp).background(Pink, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Chat, null, tint = Color.White, modifier = Modifier.size(44.dp)) }
                }
                Spacer(Modifier.height(20.dp))
                Text("ابحث عن أشخاص جدد", style = MaterialTheme.typography.headlineMedium, color = TextMain, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text("ابدأ محادثة عشوائية مع شخص متصل الآن", color = TextMuted, textAlign = TextAlign.Center)
                Spacer(Modifier.height(28.dp))
                GradientButton("ابدأ محادثة عشوائية", { startMatching() }, Modifier.fillMaxWidth(), !loading, { Icon(Icons.Default.Shuffle, null) })
                if (loading) { Spacer(Modifier.height(12.dp)); CircularProgressIndicator(color = Pink) }
                ErrorText()
            }
        }
    }

    @Composable
    private fun MessagesScreen() {
        ScreenBackground {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("الرسائل", style = MaterialTheme.typography.headlineSmall, color = TextMain, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.Search, null, tint = TextMuted)
                }
                if (chats.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد محادثات حتى الآن", color = TextMuted) }
                else LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                    items(chats.sortedByDescending { it.updatedAt }, key = { it.roomId }) { c ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).clickable { openRoom(c.roomId, c.peerId) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(c.peerName, c.peerVerified, c.peerAvatar, null, Modifier.size(54.dp), c.peerAvatarPath)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) { Row(verticalAlignment = Alignment.CenterVertically) { Text(c.peerName, color = TextMain, fontWeight = FontWeight.Bold); if (c.peerVerified) VerifiedBadge(); if (c.unreadCount > 0) { Spacer(Modifier.width(6.dp)); Surface(color = Pink, shape = CircleShape) { Text(c.unreadCount.coerceAtMost(99).toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) } } }; Text(c.lastMessage.ifBlank { "محادثة" }, color = TextMuted, maxLines = 1) }
                            Text(formatTime(c.updatedAt), color = TextMuted, style = MaterialTheme.typography.labelSmall)
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }

    @Composable
    private fun OnlineScreen() {
        // Never treat a missing/zero lastSeen value as online. Older records may
        // have online=true left over from previous app versions; they stay in
        // Firebase but are not shown as currently active.
        val fresh = onlineUsers.filter {
            it.uid == uid || (!it.manualOffline && it.online && it.lastSeen > 0L && now - it.lastSeen <= 90_000L)
        }
        val admin = fresh.firstOrNull { it.admin }
        val others = fresh.filterNot { it.admin }.sortedByDescending { it.joinedAt }
        ScreenBackground {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("نشط الآن", style = MaterialTheme.typography.headlineSmall, color = TextMain, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    Text("${fresh.size} متصل", color = Green, fontWeight = FontWeight.Bold)
                }
                if (fresh.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا يوجد مستخدمون نشطون الآن", color = TextMuted) }
                else LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                    if (admin != null) item(key = "admin") { OnlineRow(admin, true); Spacer(Modifier.height(8.dp)) }
                    items(others, key = { it.uid }) { u -> OnlineRow(u, false); Spacer(Modifier.height(8.dp)) }
                }
            }
        }
    }

    @Composable
    private fun OnlineRow(u: UserProfile, admin: Boolean) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(if (admin) Color(0xFF25123E) else Panel)
                .border(if (admin) 1.dp else 0.dp, if (admin) Color(0xFF7A3DE8) else Color.Transparent, RoundedCornerShape(18.dp))
                .clickable {
                    if (u.uid == uid) {
                        showError("ده حسابك الحالي")
                    } else {
                        val roomId = listOf(uid, u.uid).sorted().joinToString("-")
                        openRoom(roomId, u.uid)
                    }
                }
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Avatar(u.name, false, u.avatarUrl, u.gender, Modifier.size(54.dp), u.avatarStoragePath)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        u.name,
                        color = TextMain,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (u.verified) VerifiedBadge()
                    if (admin) { Spacer(Modifier.width(4.dp)); AdminBadge() }
                }
                Text(if (u.manualOffline) "غير ظاهر للآخرين" else if (admin) "متصل الآن • الإدارة" else "متصل الآن", color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
            Box(Modifier.size(11.dp).background(if (u.manualOffline) TextMuted else Green, CircleShape))
        }
    }

    @Composable
    private fun ProfileScreen() {
        val u = profile
        ScreenBackground {
            Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { IconButton({ selectedTab = 0 }) { Icon(Icons.Default.ArrowBack, null, tint = TextMain) }; Text("الملف الشخصي", color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold) }
                Spacer(Modifier.height(8.dp))
                Avatar(u?.name ?: "مستخدم", u?.verified == true, u?.avatarUrl, u?.gender, Modifier.size(122.dp), u?.avatarStoragePath)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Text(u?.name ?: "", color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold); if (u?.verified == true) VerifiedBadge() }
                if (u?.admin == true) { Spacer(Modifier.height(4.dp)); AdminBadge() }
                Text(u?.email?.ifBlank { "حساب زائر" } ?: "", color = TextMuted)
                Spacer(Modifier.height(14.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Visibility, null, tint = Pink)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("الظهور للآخرين", color = TextMain, fontWeight = FontWeight.Bold)
                            Text(if (u?.manualOffline == true) "غير متصل — لن تظهر في نشط الآن" else "متصل — يمكن للآخرين مراسلتك", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = u?.manualOffline != true, onCheckedChange = { setManualOffline(!it) })
                    }
                }
                Spacer(Modifier.height(12.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    ProfileRow(Icons.Outlined.Edit, "تعديل الملف الشخصي") { screen = "edit" }
                    ProfileRow(Icons.Outlined.Lock, "تغيير كلمة المرور") { screen = "password" }
                    ProfileRow(Icons.Outlined.Visibility, if (u?.manualOffline == true) "الظهور: غير متصل" else "الظهور: متصل") { setManualOffline(u?.manualOffline != true) }
                    ProfileRow(Icons.Outlined.Settings, "الإعدادات") { screen = "settings" }
                    if (u?.admin == true) ProfileRow(Icons.Outlined.AdminPanelSettings, "لوحة تحكم الأدمن") { screen = "admin" }
                    ProfileRow(Icons.Outlined.Logout, "تسجيل الخروج", Red) { logout() }
                }
            }
        }
    }

    @Composable
    private fun ProfileRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, tint: Color = TextMain, action: () -> Unit) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = action).padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = tint); Spacer(Modifier.width(12.dp)); Text(title, color = tint, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronLeft, null, tint = TextMuted)
        }
    }

    @Composable
    private fun ChangePasswordScreen() {
        var current by remember { mutableStateOf("") }
        var newPassword by remember { mutableStateOf("") }
        var confirm by remember { mutableStateOf("") }
        ScreenBackground {
            Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ screen = "main" }) { Icon(Icons.Default.ArrowBack, null, tint = TextMain) }
                    Text("تغيير كلمة المرور", color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.height(18.dp))
                if (auth.currentUser?.isAnonymous == true) {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Text("حساب الزائر لا يملك كلمة مرور.", color = TextMain, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("أنشئ حسابًا بالبريد الإلكتروني وكلمة مرور أولًا.", color = TextMuted)
                    }
                } else {
                    AuthField(current, { current = it }, "كلمة المرور الحالية", { Icon(Icons.Outlined.Lock, null) }, true)
                    Spacer(Modifier.height(10.dp))
                    AuthField(newPassword, { newPassword = it }, "كلمة المرور الجديدة", { Icon(Icons.Outlined.Lock, null) }, true)
                    Spacer(Modifier.height(10.dp))
                    AuthField(confirm, { confirm = it }, "تأكيد كلمة المرور", { Icon(Icons.Outlined.Lock, null) }, true)
                    Spacer(Modifier.height(18.dp))
                    GradientButton("حفظ كلمة المرور", { changePassword(current, newPassword, confirm) }, Modifier.fillMaxWidth(), !loading)
                }
                ErrorText()
            }
        }
    }

    @Composable
    private fun SettingsScreen() {
        var notificationsEnabled by remember { mutableStateOf(getSharedPreferences("dardasha_settings", Context.MODE_PRIVATE).getBoolean("notificationsEnabled", true)) }
        var messageSoundEnabled by remember { mutableStateOf(getSharedPreferences("dardasha_settings", Context.MODE_PRIVATE).getBoolean("messageSoundEnabled", true)) }
        var visibleOnline by remember(profile?.manualOffline) { mutableStateOf(profile?.manualOffline != true) }
        ScreenBackground {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ screen = "main" }) { Icon(Icons.Default.ArrowBack, null, tint = TextMain) }
                    Text("الإعدادات", color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.height(18.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Visibility, null, tint = Pink)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("الظهور متصل", color = TextMain, fontWeight = FontWeight.Bold)
                            Text(if (visibleOnline) "الآخرون يرونك في نشط الآن" else "ستستخدم التطبيق بدون الظهور في نشط الآن", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = visibleOnline, onCheckedChange = {
                            visibleOnline = it
                            setManualOffline(!it)
                        })
                    }
                }
                Spacer(Modifier.height(10.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Notifications, null, tint = Pink)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("الإشعارات", color = TextMain, fontWeight = FontWeight.Bold)
                            Text("تفضيل استقبال الإشعارات داخل التطبيق", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = notificationsEnabled, onCheckedChange = {
                            notificationsEnabled = it
                            getSharedPreferences("dardasha_settings", Context.MODE_PRIVATE).edit().putBoolean("notificationsEnabled", it).apply()
                        })
                    }
                }
                Spacer(Modifier.height(10.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.VolumeUp, null, tint = Pink)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("صوت الرسائل", color = TextMain, fontWeight = FontWeight.Bold)
                            Text("نغمة قصيرة عند وصول رسالة جديدة", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = messageSoundEnabled, onCheckedChange = {
                            messageSoundEnabled = it
                            getSharedPreferences("dardasha_settings", Context.MODE_PRIVATE).edit().putBoolean("messageSoundEnabled", it).apply()
                        })
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("آخر ظهور يظهر فقط لمن لا يستخدم وضع غير متصل. عند اختيار غير متصل تختفي من نشط الآن ولا يظهر آخر ظهورك.", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Text(BUILD_STAMP, color = Color(0xFF6F678A), style = MaterialTheme.typography.labelSmall, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        }
    }

    @Composable
    private fun EditProfileScreen() {
        var name by remember { mutableStateOf(profile?.name ?: "") }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) uploadPendingAvatar(uri) }
        ScreenBackground {
            Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { IconButton({ screen = "main" }) { Icon(Icons.Default.ArrowBack, null, tint = TextMain) }; Text("تعديل الملف الشخصي", color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold) }
                Spacer(Modifier.height(20.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Avatar(profile?.name ?: "مستخدم", profile?.verified == true, profile?.avatarUrl, profile?.gender, Modifier.size(120.dp), profile?.avatarStoragePath) }
                Spacer(Modifier.height(12.dp))
                GradientButton("اختيار صورة", { launcher.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth(), !loading, { Icon(Icons.Default.PhotoCamera, null) })
                if (profile?.avatarPending == true) { Spacer(Modifier.height(8.dp)); Text("الصورة بانتظار موافقة الأدمن ولن تظهر للعامة قبل الموافقة.", color = Pink, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
                Spacer(Modifier.height(18.dp))
                AuthField(name, { name = it }, "الاسم", { Icon(Icons.Outlined.Person, null) })
                Spacer(Modifier.height(10.dp))
                Text("الجنس: ${if (profile?.gender == "female") "أنثى" else "ذكر"} • لا يمكن تغييره بعد الاختيار", color = TextMuted)
                Spacer(Modifier.height(18.dp))
                GradientButton("حفظ", { saveName(name) }, Modifier.fillMaxWidth(), name.trim().isNotEmpty())
                ErrorText()
            }
        }
    }

    @Composable
    private fun AdminScreen() {
        var users by remember { mutableStateOf<List<UserProfile>>(emptyList()) }
        var reports by remember { mutableStateOf<List<ReportItem>>(emptyList()) }
        ScreenBackground {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { IconButton({ screen = "main" }) { Icon(Icons.Default.ArrowBack, null, tint = TextMain) }; Text("لوحة تحكم الأدمن", color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold) }
                Text("صلاحيات كاملة: إدارة المستخدمين • التوثيق • الصور • الحظر", color = TextMuted, modifier = Modifier.padding(horizontal = 18.dp))
                Spacer(Modifier.height(10.dp))
                LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
                    item { AdminSectionTitle("البلاغات") }
                    if (reports.isEmpty()) item { Text("لا توجد بلاغات جديدة", color = TextMuted, modifier = Modifier.padding(bottom = 8.dp)) }
                    items(reports.sortedByDescending { it.createdAt }, key = { it.id }) { r ->
                        GlassCard(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Text("السبب: ${r.reason}", color = Pink, fontWeight = FontWeight.Bold)
                            Text("المُبلّغ: ${r.reporterId}", color = TextMuted, maxLines = 1)
                            Text("على المستخدم: ${r.reportedId}", color = TextMuted, maxLines = 1)
                            Text(formatDateTime(r.createdAt), color = TextMuted, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    item { AdminSectionTitle("المستخدمون") }
                    items(users.sortedWith(compareByDescending<UserProfile> { it.admin }.thenByDescending { it.joinedAt }), key = { it.uid }) { u -> AdminUserCard(u) }
                }
            }
        }
        DisposableEffect(uid) {
            val ref = db.reference.child("users")
            val listener = object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) { users = s.children.mapNotNull { parseUser(it) } }
                override fun onCancelled(e: DatabaseError) { showError(e.message) }
            }
            ref.addValueEventListener(listener)
            onDispose { ref.removeEventListener(listener) }
        }
        DisposableEffect(uid) {
            val ref = db.reference.child("reports")
            val listener = object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    reports = s.children.mapNotNull { snap ->
                        ReportItem(snap.key ?: return@mapNotNull null, snap.child("reporterId").getValue(String::class.java).orEmpty(), snap.child("reportedId").getValue(String::class.java).orEmpty(), snap.child("reason").getValue(String::class.java).orEmpty(), snap.child("createdAt").getValue(Long::class.java) ?: 0L)
                    }
                }
                override fun onCancelled(e: DatabaseError) { showError(e.message) }
            }
            ref.addValueEventListener(listener)
            onDispose { ref.removeEventListener(listener) }
        }
    }

    @Composable
    private fun AdminSectionTitle(text: String) { Text(text, color = Pink, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 8.dp)) }

    @Composable
    private fun AdminUserCard(u: UserProfile) {
        GlassCard(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(u.name, u.verified || u.admin, u.avatarUrl, u.gender, Modifier.size(52.dp), u.avatarStoragePath)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Row(verticalAlignment = Alignment.CenterVertically) { Text(u.name, color = TextMain, fontWeight = FontWeight.Bold); if (u.verified) VerifiedBadge(); if (u.admin) AdminBadge() }; Text(u.email.ifBlank { "زائر" }, color = TextMuted, maxLines = 1) }
            }
            Spacer(Modifier.height(10.dp))
            if (u.avatarPending && u.avatarPendingUrl.isNotBlank()) {
                Text("صورة جديدة بانتظار المراجعة", color = Pink, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(7.dp))
                RemoteStorageImage(u.avatarPendingUrl, u.avatarPendingStoragePath, "الصورة المعلقة", Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(16.dp)))
                Spacer(Modifier.height(7.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    GradientButton("قبول الصورة", { approveAvatar(u) }, Modifier.weight(1f), true, { Icon(Icons.Default.Check, null) })
                    OutlinedButton({ rejectAvatar(u) }, Modifier.weight(1f)) { Text("رفض") }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton({ setVerified(u.uid, !u.verified) }, Modifier.weight(1f)) { Text(if (u.verified) "إلغاء التوثيق" else "توثيق ✓") }
                OutlinedButton({ setBanned(u.uid, !u.banned) }, Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = if (u.banned) Green else Red)) { Text(if (u.banned) "إلغاء الحظر" else "حظر") }
            }
            if (!u.admin) {
                Spacer(Modifier.height(6.dp))
                OutlinedButton({ deleteUserData(u) }, Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) {
                    Icon(Icons.Default.DeleteForever, null)
                    Spacer(Modifier.width(6.dp))
                    Text("حذف بيانات المستخدم")
                }
            }
        }
    }

    @Composable
    private fun ChatScreen() {
        val peer = currentPeer
        var text by remember(currentRoom) { mutableStateOf("") }
        var menu by remember { mutableStateOf(false) }
        var reportDialog by remember { mutableStateOf(false) }
        val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) uploadChatImage(uri) }
        val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) startRecording() else showError("نحتاج إذن الميكروفون لإرسال تسجيل صوتي") }
        ScreenBackground {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().background(Color(0xFF0A091B)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ closeRoom() }) { Icon(Icons.Default.ArrowBack, null, tint = TextMain) }
                    Avatar(peer?.name ?: "مستخدم", peer?.verified == true, peer?.avatarUrl, peer?.gender, Modifier.size(42.dp), peer?.avatarStoragePath)
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Text(peer?.name ?: "مستخدم", color = TextMain, fontWeight = FontWeight.Bold); if (peer?.verified == true) VerifiedBadge() }
                        Text(peerStatusText(peer), color = if (peer?.online == true) Green else TextMuted, style = MaterialTheme.typography.labelSmall)
                        if (peerTyping) Text("يكتب الآن…", color = Pink, style = MaterialTheme.typography.labelSmall)
                    }
                    IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, null, tint = TextMain) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(if (iBlockedPeer) "إلغاء الحظر" else "حظر المستخدم") }, onClick = { menu = false; if (iBlockedPeer) unblockPeer() else blockPeer() }, leadingIcon = { Icon(if (iBlockedPeer) Icons.Default.LockOpen else Icons.Default.Block, null) })
                        DropdownMenuItem(text = { Text("إبلاغ عن المستخدم") }, onClick = { menu = false; reportDialog = true }, leadingIcon = { Icon(Icons.Default.Report, null) })
                    }
                }
                if (reportDialog) {
                    AlertDialog(
                        onDismissRequest = { reportDialog = false },
                        title = { Text("إبلاغ عن المستخدم") },
                        text = { Column {
                            listOf("إساءة أو شتائم", "تحرش أو محتوى غير مناسب", "سبام", "اسم مخالف").forEach { reason ->
                                TextButton(onClick = { reportDialog = false; reportPeer(reason) }, modifier = Modifier.fillMaxWidth()) { Text(reason, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start) }
                            }
                        } },
                        confirmButton = { TextButton(onClick = { reportDialog = false }) { Text("إلغاء") } }
                    )
                }
                if (isBlocked) Box(Modifier.fillMaxWidth().background(Color(0xFF341126)).padding(10.dp), contentAlignment = Alignment.Center) { Text("تم حظر هذا المستخدم", color = Red, fontWeight = FontWeight.Bold) }
                LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(10.dp), reverseLayout = false) {
                    items(messages.filter { it.id !in deletedMessageIds && (it.type != "image" || it.expiresAt == 0L || it.expiresAt > now) }, key = { it.id }) { m -> MessageBubble(m) }
                }
                Row(Modifier.fillMaxWidth().background(Color(0xFF0A091B)).padding(8.dp).navigationBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ imageLauncher.launch(arrayOf("image/*")) }, enabled = !isBlocked && !loading) { Icon(Icons.Default.CameraAlt, "صورة", tint = Pink) }
                    IconButton({ if (isRecording) stopRecordingAndSend() else micLauncher.launch(Manifest.permission.RECORD_AUDIO) }, enabled = !isBlocked && !loading) { Icon(if (isRecording) Icons.Default.Stop else Icons.Default.Mic, "صوت", tint = if (isRecording) Red else Blue) }
                    OutlinedTextField(
                        text,
                        {
                            if (it.length <= MAX_MESSAGE_LENGTH) {
                                text = it
                                setTyping(it.isNotBlank())
                            }
                        },
                        Modifier.weight(1f), enabled = !isBlocked && !loading, placeholder = { Text("اكتب رسالة") }, singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Panel2, unfocusedContainerColor = Panel, focusedBorderColor = Pink, unfocusedBorderColor = Color(0xFF3A3355), focusedTextColor = TextMain, unfocusedTextColor = TextMain, cursorColor = Pink)
                    )
                    IconButton({ val v = text.trim(); if (v.isNotEmpty()) { sendMessage(v); text = ""; setTyping(false) } }, enabled = text.trim().isNotEmpty() && !isBlocked && !loading) { Icon(Icons.Default.Send, "إرسال", tint = Pink) }
                }
            }
        }
    }

    @Composable
    private fun MessageTextWithLinks(text: String, mine: Boolean) {
        val urlRegex = Regex("https?://[^\\s]+")
        val annotated = buildAnnotatedString {
            var cursor = 0
            urlRegex.findAll(text).forEach { match ->
                append(text.substring(cursor, match.range.first))
                pushStringAnnotation("URL", match.value)
                withStyle(SpanStyle(color = if (mine) Color.White else Blue, textDecoration = TextDecoration.Underline)) { append(match.value) }
                pop()
                cursor = match.range.last + 1
            }
            append(text.substring(cursor))
        }
        ClickableText(text = annotated, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), style = MaterialTheme.typography.bodyLarge.copy(color = TextMain), onClick = { offset ->
            annotated.getStringAnnotations("URL", offset, offset).firstOrNull()?.let {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it.item))) } catch (_: Exception) { showError("تعذر فتح الرابط") }
            }
        })
    }

    @Composable
    private fun MessageBubble(m: Msg) {
        val mine = m.senderId == uid
        var menu by remember(m.id) { mutableStateOf(false) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
            Column(horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                Column(Modifier.combinedClickable(onClick = {}, onLongClick = { menu = true })) {
                    when (m.type) {
                        "image" -> RemoteStorageImage(m.imageUrl, m.storagePath, "صورة", Modifier.widthIn(max = 250.dp).heightIn(max = 280.dp).clip(RoundedCornerShape(18.dp)))
                        "audio" -> OutlinedButton({ playAudio(m.audioUrl) }) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text("تشغيل التسجيل") }
                        else -> Surface(color = if (mine) Color(0xFF6D25D9) else Panel2, shape = RoundedCornerShape(18.dp)) {
                            MessageTextWithLinks(m.text, mine)
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(formatTime(m.timestamp), color = TextMuted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                    if (mine) {
                        val read = m.readAt > 0L
                        val delivered = m.deliveredAt > 0L
                        Text(if (read) "✓✓" else if (delivered) "✓✓" else "✓", color = if (read) Blue else TextMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("حذف لدي") }, onClick = { menu = false; deleteForMe(m.id) }, leadingIcon = { Icon(Icons.Default.DeleteOutline, null) })
                    if (mine) DropdownMenuItem(text = { Text("حذف لدى الجميع") }, onClick = { menu = false; deleteForEveryone(m) }, leadingIcon = { Icon(Icons.Default.DeleteForever, null) })
                }
            }
        }
        Spacer(Modifier.height(5.dp))
    }

    @Composable
    private fun GenderChoice(value: String, onChange: (String) -> Unit) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GenderCard("male", "ذكر", value == "male", onChange, Modifier.weight(1f))
            GenderCard("female", "أنثى", value == "female", onChange, Modifier.weight(1f))
        }
    }

    @Composable
    private fun GenderCard(gender: String, label: String, selected: Boolean, onChange: (String) -> Unit, modifier: Modifier) {
        Column(modifier.clip(RoundedCornerShape(18.dp)).background(if (selected) Color(0xFF28104D) else Panel).border(1.dp, if (selected) (if (gender == "male") Blue else Pink) else Color(0xFF363052), RoundedCornerShape(18.dp)).clickable { onChange(gender) }.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            GenderAvatar(gender, Modifier.size(68.dp)); Spacer(Modifier.height(5.dp)); Text(label, color = if (selected) Color.White else TextMuted, fontWeight = FontWeight.Bold)
        }
    }

    @Composable
    private fun GenderAvatar(gender: String, modifier: Modifier) {
        val base = if (gender == "female") Pink else Blue
        Canvas(modifier.clip(CircleShape).background(base.copy(alpha = .18f))) {
            val w = size.width; val h = size.height
            drawCircle(base, radius = w * .23f, center = Offset(w / 2f, h * .34f))
            drawRoundRect(base, topLeft = Offset(w * .23f, h * .52f), size = androidx.compose.ui.geometry.Size(w * .54f, h * .34f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * .18f, w * .18f))
            if (gender == "female") {
                drawArc(Color(0xFF4A194D), 190f, 160f, false, style = Stroke(w * .16f, cap = StrokeCap.Round), topLeft = Offset(w * .17f, h * .08f), size = androidx.compose.ui.geometry.Size(w * .66f, h * .48f))
            } else {
                drawLine(Color(0xFF15335D), Offset(w * .31f, h * .19f), Offset(w * .69f, h * .19f), strokeWidth = w * .12f, cap = StrokeCap.Round)
            }
        }
    }

    @Composable
    private fun RemoteStorageImage(
        url: String?,
        storagePath: String?,
        contentDescription: String?,
        modifier: Modifier,
        contentScale: ContentScale = ContentScale.Crop
    ) {
        var resolvedUrl by remember(url, storagePath) { mutableStateOf(url.orEmpty()) }
        LaunchedEffect(url, storagePath) {
            if (!storagePath.isNullOrBlank()) {
                storage.reference.child(storagePath).downloadUrl
                    .addOnSuccessListener { resolvedUrl = it.toString() }
            }
        }
        if (resolvedUrl.isNotBlank()) {
            AsyncImage(resolvedUrl, contentDescription, modifier, contentScale = contentScale)
        }
    }

    @Composable
    private fun Avatar(name: String, verified: Boolean, url: String?, gender: String?, modifier: Modifier, storagePath: String? = null) {
        Box(modifier.clip(CircleShape).background(Color(0xFF26154B)), contentAlignment = Alignment.Center) {
            if (!url.isNullOrBlank() || !storagePath.isNullOrBlank()) RemoteStorageImage(url, storagePath, "صورة المستخدم", Modifier.fillMaxSize())
            else GenderAvatar(if (gender == "female") "female" else "male", Modifier.fillMaxSize())

        }
    }

    @Composable
    private fun VerifiedBadge() { Box(Modifier.padding(start = 4.dp).size(18.dp).background(Blue, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(12.dp)) } }

    @Composable
    private fun AdminBadge() { Surface(color = Color(0xFF35203F), shape = RoundedCornerShape(8.dp)) { Text("ADMIN", color = Color(0xFFFFC24B), fontSize = MaterialTheme.typography.labelSmall.fontSize, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) } }

    @Composable
    private fun ErrorText() { errorText?.let { Text(it, color = Red, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(10.dp)) } }

    private fun loadProfileOrSetup() {
        if (uid.isBlank()) return
        db.reference.child("users").child(uid).get().addOnSuccessListener { s ->
            val u = parseUser(s)
            profile = u
            // Repair old accounts that were created before the name filter existed.
            if (u != null && u.name.isNotBlank()) {
                val safe = sanitizeDisplayName(u.name)
                if (safe != u.name) {
                    db.reference.child("users").child(uid).child("name").setValue(safe)
                    profile = u.copy(name = safe)
                }
            }
            if (u?.banned == true) { showError("هذا الحساب محظور من الإدارة"); logout(); return@addOnSuccessListener }
            if (u == null || u.name.isBlank() || u.gender.isBlank()) screen = "guest" else { screen = "main"; if (uid == OWNER_UID) normalizeAdminFlags(); startListeners(); setPresence(true); requestNotificationPermissionIfNeeded() }
        }.addOnFailureListener { showError(it.message ?: "تعذر تحميل الحساب") }
    }

    private fun normalizeAdminFlags() {
        if (uid != OWNER_UID) return
        db.reference.child("users").get().addOnSuccessListener { snap ->
            snap.children.forEach { child ->
                val id = child.key ?: return@forEach
                val isAdmin = child.child("admin").getValue(Boolean::class.java) ?: false
                if (id != OWNER_UID && isAdmin) db.reference.child("users").child(id).child("admin").setValue(false)
            }
            db.reference.child("users").child(OWNER_UID).child("admin").setValue(true)
        }
    }

    private fun createGuestProfile(name: String, gender: String) {
        loading = true; errorText = null
        if (uid.isBlank()) auth.signInAnonymously().addOnSuccessListener { uid = it.user!!.uid; saveProfile(sanitizeDisplayName(name), "", gender, true) }.addOnFailureListener { loading = false; showError(it.message ?: "تعذر دخول الزائر") }
        else saveProfile(sanitizeDisplayName(name), "", gender, true)
    }

    private fun register(name: String, email: String, password: String, gender: String) {
        loading = true; errorText = null
        val current = auth.currentUser
        val credential = EmailAuthProvider.getCredential(email.trim(), password)
        val task = if (current?.isAnonymous == true) current.linkWithCredential(credential) else auth.createUserWithEmailAndPassword(email.trim(), password)
        task.addOnSuccessListener { uid = it.user?.uid ?: uid; saveProfile(sanitizeDisplayName(name), email.trim(), gender, false) }.addOnFailureListener { loading = false; showError(it.message ?: "تعذر إنشاء الحساب") }
    }

    private fun signInWithGoogle() {
        val clientIdRes = resources.getIdentifier("default_web_client_id", "string", packageName)
        if (clientIdRes == 0) {
            showError("Google غير مفعّل في Firebase أو ملف google-services.json الحالي لا يحتوي OAuth Client. فعّل Google ونزّل الملف الجديد وضعه داخل app/")
            return
        }
        val serverClientId = getString(clientIdRes)
        if (serverClientId.isBlank()) {
            showError("معرّف Google OAuth غير موجود. نزّل google-services.json الجديد من Firebase وضعه داخل app/")
            return
        }
        loading = true
        val credentialManager = CredentialManager.create(this)
        val googleIdOption = GetGoogleIdOption.Builder()
            .setServerClientId(serverClientId)
            .setFilterByAuthorizedAccounts(false)
            .setAutoSelectEnabled(false)
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(googleIdOption).build()
        lifecycleScope.launch {
            try {
                val result = credentialManager.getCredential(this@MainActivity, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleCredential = try {
                        GoogleIdTokenCredential.createFrom(credential.data)
                    } catch (e: GoogleIdTokenParsingException) {
                        loading = false
                        showError("تعذر قراءة حساب Google")
                        return@launch
                    }
                    val firebaseCredential = GoogleAuthProvider.getCredential(googleCredential.idToken, null)
                    val current = auth.currentUser
                    val authTask = if (current?.isAnonymous == true) current.linkWithCredential(firebaseCredential) else auth.signInWithCredential(firebaseCredential)
                    authTask
                        .addOnSuccessListener { uid = it.user?.uid ?: uid; loadProfileOrSetup() }
                        .addOnFailureListener { loading = false; showError(it.message ?: "تعذر تسجيل الدخول عبر Google") }
                } else {
                    loading = false
                    showError("لم يتم اختيار حساب Google صالح")
                }
            } catch (e: Exception) {
                loading = false
                showError(e.message ?: "تعذر تسجيل الدخول عبر Google")
            }
        }
    }

    private fun login(email: String, password: String) {
        loading = true; errorText = null
        auth.signInWithEmailAndPassword(email.trim(), password).addOnSuccessListener { uid = it.user!!.uid; loadProfileOrSetup() }.addOnFailureListener { loading = false; showError(it.message ?: "تعذر تسجيل الدخول") }
    }

    private fun resetPassword(email: String) {
        if (!email.contains("@")) { showError("اكتب بريدًا إلكترونيًا صحيحًا"); return }
        auth.sendPasswordResetEmail(email.trim()).addOnSuccessListener { showError("تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك") }.addOnFailureListener { showError(it.message ?: "تعذر إرسال الرابط") }
    }

    private fun changePassword(current: String, newPassword: String, confirm: String) {
        val user = auth.currentUser
        val email = user?.email
        if (user == null || email.isNullOrBlank() || user.isAnonymous) { showError("هذا الحساب لا يدعم تغيير كلمة المرور"); return }
        if (current.isBlank() || newPassword.length < 6 || confirm.isBlank()) { showError("أدخل كلمة المرور الحالية والجديدة وتأكيدها"); return }
        if (newPassword != confirm) { showError("كلمتا المرور الجديدتان غير متطابقتين"); return }
        loading = true
        user.reauthenticate(EmailAuthProvider.getCredential(email, current))
            .continueWithTask { user.updatePassword(newPassword) }
            .addOnSuccessListener { loading = false; showError("تم تغيير كلمة المرور بنجاح") }
            .addOnFailureListener { loading = false; showError(it.message ?: "تعذر تغيير كلمة المرور") }
    }

    private fun saveProfile(name: String, email: String, gender: String, anonymous: Boolean) {
        val safeName = sanitizeDisplayName(name)
        val ref = db.reference.child("users").child(uid)
        ref.get().addOnSuccessListener { existing ->
            val old = parseUser(existing)
            val data = mutableMapOf<String, Any>(
                "uid" to uid, "name" to safeName, "email" to email,
                "gender" to (old?.gender?.takeIf { it.isNotBlank() } ?: gender),
                "verified" to (old?.verified ?: false),
                "banned" to (old?.banned ?: false),
                "online" to (old?.manualOffline != true),
                "joinedAt" to if ((old?.joinedAt ?: 0L) > 0L) old!!.joinedAt else ServerValue.TIMESTAMP,
                "lastSeen" to ServerValue.TIMESTAMP,
                "manualOffline" to (old?.manualOffline ?: false)
            )
            // Admin is derived from the fixed owner UID. Preserve any legacy
            // non-owner admin flag instead of trying to rewrite it during profile updates.
            if (uid == OWNER_UID || !existing.hasChild("admin")) {
                data["admin"] = (uid == OWNER_UID)
            }
            ref.updateChildren(data).addOnSuccessListener {
                if (old?.manualOffline == true) setPresence(false) else setPresence(true)
                loading = false
                loadProfileOrSetup()
            }.addOnFailureListener { loading = false; showError(it.message ?: "تعذر حفظ البيانات") }
        }.addOnFailureListener {
            loading = false
            showError(it.message ?: "تعذر قراءة بيانات الحساب")
        }
    }

    private fun setManualOffline(offline: Boolean) {
        if (uid.isBlank()) return
        db.reference.child("users").child(uid).updateChildren(mapOf("manualOffline" to offline, "online" to !offline, "lastSeen" to ServerValue.TIMESTAMP))
            .addOnSuccessListener {
                profile = profile?.copy(manualOffline = offline, online = !offline, lastSeen = System.currentTimeMillis())
                if (offline) db.reference.child("waiting").child(uid).removeValue() else setPresence(true)
            }
            .addOnFailureListener { showError(it.message ?: "تعذر تغيير حالة الظهور") }
    }

    private fun setPresence(isOnline: Boolean) {
        if (uid.isBlank()) return
        if (isOnline && profile?.manualOffline == true) return
        val ref = db.reference.child("users").child(uid)
        if (isOnline) {
            // Register disconnect handlers once per foreground session. Do not
            // rewrite joinedAt here; it is the user's original join time.
            ref.child("online").onDisconnect().setValue(false)
            ref.child("lastSeen").onDisconnect().setValue(ServerValue.TIMESTAMP)
            ref.updateChildren(mapOf("online" to true, "lastSeen" to ServerValue.TIMESTAMP))
        } else {
            ref.updateChildren(mapOf("online" to false, "lastSeen" to ServerValue.TIMESTAMP))
        }
    }

    private fun startListeners() {
        usersListener?.let { db.reference.child("users").removeEventListener(it) }
        usersListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                onlineUsers.clear()
                s.children.mapNotNull { parseUser(it) }.forEach { if (it.online || it.uid == uid) onlineUsers.add(it) }
                parseUser(s.child(uid))?.let { profile = it }
            }
            override fun onCancelled(e: DatabaseError) { showError(e.message) }
        }
        db.reference.child("users").addValueEventListener(usersListener!!)

        chatsListener?.let { db.reference.child("userChats").child(uid).removeEventListener(it) }
        chatsListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                chats.clear()
                s.children.mapNotNull { snap -> ChatPreview(snap.key ?: return@mapNotNull null, snap.child("peerId").getValue(String::class.java).orEmpty(), snap.child("peerName").getValue(String::class.java).orEmpty(), snap.child("peerVerified").getValue(Boolean::class.java) ?: false, snap.child("peerAvatar").getValue(String::class.java).orEmpty(), snap.child("peerAvatarPath").getValue(String::class.java).orEmpty(), snap.child("lastMessage").getValue(String::class.java).orEmpty(), snap.child("updatedAt").getValue(Long::class.java) ?: 0L, snap.child("unreadCount").getValue(Int::class.java) ?: 0) }.forEach { chats.add(it) }
                val totalUnread = chats.sumOf { it.unreadCount }
                if (unreadInitialized && totalUnread > lastUnreadTotal && screen != "chat") playMessageSoundIfEnabled(true)
                lastUnreadTotal = totalUnread
                unreadInitialized = true
            }
            override fun onCancelled(e: DatabaseError) { showError(e.message) }
        }
        db.reference.child("userChats").child(uid).addValueEventListener(chatsListener!!)
    }

    private fun startMatching() {
        if (uid.isBlank()) return
        if (profile?.manualOffline == true) { showError("فعّل الظهور متصل لاستخدام العشوائي"); return }
        loading = true; errorText = null
        val root = db.reference.child("waiting")
        val me = root.child(uid)
        me.onDisconnect().removeValue()
        root.runTransaction(object : Transaction.Handler {
            override fun doTransaction(d: MutableData): Transaction.Result {
                var peer: String? = null
                for (c in d.children) if (c.key != uid && c.child("roomId").value == null) { peer = c.key; break }
                if (peer == null) d.child(uid).value = mapOf("createdAt" to ServerValue.TIMESTAMP)
                else {
                    val p = peer!!; val roomId = listOf(uid, p).sorted().joinToString("-")
                    d.child(uid).value = mapOf("createdAt" to ServerValue.TIMESTAMP, "roomId" to roomId, "peerId" to p)
                    d.child(p).child("roomId").value = roomId; d.child(p).child("peerId").value = uid
                }
                return Transaction.success(d)
            }
            override fun onComplete(e: DatabaseError?, committed: Boolean, s: DataSnapshot?) {
                if (e != null || !committed) { loading = false; showError(e?.message ?: "تعذر البحث"); return }
                val meSnap = s?.child(uid); val room = meSnap?.child("roomId")?.getValue(String::class.java)
                if (!room.isNullOrBlank()) openRoom(room, meSnap.child("peerId").getValue(String::class.java).orEmpty()) else waitForMatch()
            }
        })
    }

    private fun waitForMatch() {
        val ref = db.reference.child("waiting").child(uid)
        waitingListener?.let { ref.removeEventListener(it) }
        waitingListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                val room = s.child("roomId").getValue(String::class.java)
                if (!room.isNullOrBlank()) { ref.removeValue(); waitingListener?.let { ref.removeEventListener(it) }; waitingListener = null; openRoom(room, s.child("peerId").getValue(String::class.java).orEmpty()) }
            }
            override fun onCancelled(e: DatabaseError) { loading = false; showError(e.message) }
        }
        ref.addValueEventListener(waitingListener!!)
    }

    private fun openRoom(roomId: String, peerId: String) {
        if (peerId.isBlank() || peerId == uid) { showError("لا يمكن فتح محادثة مع هذا الحساب"); return }
        db.reference.child("waiting").child(uid).removeValue()
        stopTyping()
        currentRoomRef?.let { old -> messagesListener?.let { old.removeEventListener(it) } }
        messageDeletesListener?.let { db.reference.child("messageDeletes").child(uid).child(roomId).removeEventListener(it) }
        typingListener?.let { db.reference.child("typing").child(peerId).removeEventListener(it) }
        currentRoomRef = null; messagesListener = null; messageDeletesListener = null; typingListener = null
        currentRoom = roomId; currentPeer = null; messages.clear(); deletedMessageIds.clear(); peerTyping = false; isBlocked = false; iBlockedPeer = false; loading = false; errorText = null; screen = "chat"

        db.reference.child("users").child(peerId).get().addOnSuccessListener { snap -> currentPeer = parseUser(snap); checkBlocked() }.addOnFailureListener { showError("تعذر تحميل بيانات المستخدم") }

        val membersRef = db.reference.child("rooms").child(roomId).child("members")
        membersRef.child(uid).setValue(true).addOnSuccessListener {
            // Each participant adds only their own UID. The other participant
            // will become a member automatically when they open the same room.
            attachRoomMessages(roomId, peerId)
            markRoomMessagesRead(roomId)
            db.reference.child("userChats").child(uid).child(roomId).child("unreadCount").setValue(0)
        }.addOnFailureListener { showError(it.message ?: "تعذر فتح المحادثة") }
    }

    private fun addMessageSnapshot(s: DataSnapshot) {
        val type = s.child("type").getValue(String::class.java).orEmpty().ifBlank { "text" }
        val expires = s.child("expiresAt").getValue(Long::class.java) ?: 0L
        if (type == "image" && expires > 0 && expires <= System.currentTimeMillis()) { s.ref.removeValue(); return }
        val m = Msg(
            s.key ?: return,
            s.child("senderId").getValue(String::class.java).orEmpty(),
            type,
            s.child("text").getValue(String::class.java).orEmpty(),
            s.child("imageUrl").getValue(String::class.java).orEmpty(),
            s.child("audioUrl").getValue(String::class.java).orEmpty(),
            s.child("storagePath").getValue(String::class.java).orEmpty(),
            s.child("timestamp").getValue(Long::class.java) ?: 0L,
            expires,
            s.child("deliveredAt").getValue(Long::class.java) ?: 0L,
            s.child("readAt").getValue(Long::class.java) ?: 0L
        )
        val idx = messages.indexOfFirst { it.id == m.id }
        if (idx >= 0) messages[idx] = m else messages.add(m)
        messages.sortBy { it.timestamp }
    }

    private fun attachRoomMessages(roomId: String, peerId: String) {
        if (currentRoom != roomId) return
        currentRoomRef?.let { old -> messagesListener?.let { old.removeEventListener(it) } }
        val ref = db.reference.child("rooms").child(roomId).child("messages")
        currentRoomRef = ref
        messageListenerPrimed = false
        messagesListener = object : ChildEventListener {
            override fun onChildAdded(s: DataSnapshot, p: String?) {
                val wasKnown = messages.any { it.id == s.key }
                addMessageSnapshot(s)
                if (!wasKnown && s.child("senderId").getValue(String::class.java) != uid) {
                    markMessageRead(roomId, s.key.orEmpty())
                    if (messageListenerPrimed) playMessageSoundIfEnabled(false)
                }
            }
            override fun onChildChanged(s: DataSnapshot, p: String?) {
                val idx = messages.indexOfFirst { it.id == s.key }
                if (idx >= 0) {
                    val old = messages[idx]
                    messages[idx] = old.copy(deliveredAt = s.child("deliveredAt").getValue(Long::class.java) ?: old.deliveredAt, readAt = s.child("readAt").getValue(Long::class.java) ?: old.readAt)
                }
            }
            override fun onChildRemoved(s: DataSnapshot) { messages.removeAll { it.id == s.key } }
            override fun onChildMoved(s: DataSnapshot, p: String?) {}
            override fun onCancelled(e: DatabaseError) { showError(e.message) }
        }
        ref.addChildEventListener(messagesListener!!)
        ref.get().addOnSuccessListener { s ->
            s.children.forEach { addMessageSnapshot(it) }
            markRoomMessagesRead(roomId)
            messageListenerPrimed = true
        }.addOnFailureListener { messageListenerPrimed = true }

        val deletesRef = db.reference.child("messageDeletes").child(uid).child(roomId)
        messageDeletesListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) { deletedMessageIds.clear(); s.children.forEach { if (it.getValue(Boolean::class.java) == true) it.key?.let(deletedMessageIds::add) } }
            override fun onCancelled(e: DatabaseError) {}
        }
        deletesRef.addValueEventListener(messageDeletesListener!!)

        typingListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) { peerTyping = s.getValue(Boolean::class.java) == true }
            override fun onCancelled(e: DatabaseError) {}
        }
        db.reference.child("typing").child(peerId).addValueEventListener(typingListener!!)

        ref.orderByChild("expiresAt").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                val cutoff = System.currentTimeMillis() - MESSAGE_RETENTION_MS
                s.children.forEach {
                    val ex = it.child("expiresAt").getValue(Long::class.java) ?: 0L
                    val ts = it.child("timestamp").getValue(Long::class.java) ?: 0L
                    val path = it.child("storagePath").getValue(String::class.java).orEmpty()
                    if ((ex > 0 && ex <= System.currentTimeMillis()) || (ts > 0 && ts < cutoff)) {
                        it.ref.removeValue()
                        if (path.isNotBlank()) storage.reference.child(path).delete()
                    }
                }
            }
            override fun onCancelled(e: DatabaseError) {}
        })
    }

    private fun markRoomMessagesRead(roomId: String) {
        val ref = db.reference.child("rooms").child(roomId).child("messages")
        ref.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) { s.children.forEach { if (it.child("senderId").getValue(String::class.java) != uid && it.child("readAt").getValue(Long::class.java) ?: 0L == 0L) markMessageRead(roomId, it.key.orEmpty()) } }
            override fun onCancelled(e: DatabaseError) {}
        })
    }

    private fun markMessageRead(roomId: String, messageId: String) {
        if (messageId.isBlank()) return
        val ts = ServerValue.TIMESTAMP
        db.reference.child("rooms").child(roomId).child("messages").child(messageId).updateChildren(mapOf("deliveredAt" to ts, "readAt" to ts))
    }

    private fun setTyping(value: Boolean) {
        if (uid.isBlank()) return
        typingRunnable?.let(typingHandler::removeCallbacks)
        val ref = db.reference.child("typing").child(uid)
        if (!value) { ref.onDisconnect().cancel(); ref.setValue(false); return }
        ref.onDisconnect().setValue(false)
        ref.setValue(true)
        typingRunnable = Runnable { ref.setValue(false) }
        typingHandler.postDelayed(typingRunnable!!, TYPING_TIMEOUT_MS)
    }

    private fun stopTyping() { typingRunnable?.let(typingHandler::removeCallbacks); typingRunnable = null; if (uid.isNotBlank()) db.reference.child("typing").child(uid).setValue(false) }

    private fun checkBlocked() {
        val peer = currentPeer ?: return
        db.reference.child("blocks").child(uid).child(peer.uid).get().addOnSuccessListener { a ->
            iBlockedPeer = a.exists()
            db.reference.child("blocks").child(peer.uid).child(uid).get().addOnSuccessListener { b -> isBlocked = iBlockedPeer || b.exists() }
        }
    }

    private fun reserveMessageSlot(action: () -> Unit) {
        if (uid.isBlank()) return
        val ref = db.reference.child("rateLimits").child(uid)
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(d: MutableData): Transaction.Result {
                val nowTs = System.currentTimeMillis()
                val windowStart = d.child("windowStart").getValue(Long::class.java) ?: 0L
                val count = d.child("count").getValue(Int::class.java) ?: 0
                if (windowStart <= 0L || nowTs - windowStart >= 10_000L) { d.child("windowStart").value = nowTs; d.child("count").value = 1; return Transaction.success(d) }
                if (count >= 6) return Transaction.abort()
                d.child("count").value = count + 1
                return Transaction.success(d)
            }
            override fun onComplete(e: DatabaseError?, committed: Boolean, s: DataSnapshot?) {
                if (e != null) { showError(e.message); return }
                if (!committed) { showError("تم إيقاف الإرسال مؤقتًا لتقليل السبام"); return }
                action()
            }
        })
    }

    private fun reportPeer(reason: String) {
        val peer = currentPeer
        if (peer == null) {
            showError("لا يوجد مستخدم للإبلاغ عنه")
        } else {
            val id = db.reference.child("reports").push().key
            if (id.isNullOrBlank()) {
                showError("تعذر إنشاء البلاغ")
            } else {
                val data = mapOf<String, Any>(
                    "reporterId" to uid,
                    "reportedId" to peer.uid,
                    "reason" to reason,
                    "createdAt" to ServerValue.TIMESTAMP
                )
                db.reference.child("reports").child(id).setValue(data)
                    .addOnSuccessListener { showError("تم إرسال البلاغ للإدارة") }
                    .addOnFailureListener { showError(it.message ?: "تعذر إرسال البلاغ") }
            }
        }
    }

    private fun sendMessage(text: String) {
        val room = currentRoom ?: return; val peer = currentPeer ?: return; if (isBlocked) return
        reserveMessageSlot {
            val ref = db.reference.child("rooms").child(room).child("messages").push()
            val data = mapOf<String, Any>("senderId" to uid, "type" to "text", "text" to text.take(MAX_MESSAGE_LENGTH), "timestamp" to ServerValue.TIMESTAMP, "expiresAt" to 0L, "deliveredAt" to 0L, "readAt" to 0L, "storagePath" to "")
            ref.setValue(data).addOnSuccessListener { updateChatPreview(peer, text) }.addOnFailureListener { showError(it.message ?: "فشل إرسال الرسالة") }
        }
    }

    private fun updateChatPreview(peer: UserProfile, last: String) {
        val room = currentRoom ?: return
        val nowTs = System.currentTimeMillis()
        val mine = mapOf("peerId" to peer.uid, "peerName" to peer.name, "peerVerified" to peer.verified, "peerAvatar" to peer.avatarUrl, "peerAvatarPath" to peer.avatarStoragePath, "lastMessage" to last, "updatedAt" to nowTs, "unreadCount" to 0)
        val peerRef = db.reference.child("userChats").child(peer.uid).child(room)
        db.reference.child("userChats").child(uid).child(room).setValue(mine)
        peerRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(d: MutableData): Transaction.Result {
                val old = d.child("unreadCount").getValue(Int::class.java) ?: 0
                d.child("peerId").value = uid
                d.child("peerName").value = profile?.name ?: "مستخدم"
                d.child("peerVerified").value = profile?.verified ?: false
                d.child("peerAvatar").value = profile?.avatarUrl ?: ""
                d.child("peerAvatarPath").value = profile?.avatarStoragePath ?: ""
                d.child("lastMessage").value = last
                d.child("updatedAt").value = nowTs
                d.child("unreadCount").value = old + 1
                return Transaction.success(d)
            }
            override fun onComplete(e: DatabaseError?, committed: Boolean, s: DataSnapshot?) { if (e != null) showError(e.message) }
        })
    }

    private fun uploadFileAndGetUrl(
        path: String,
        file: File,
        metadata: com.google.firebase.storage.StorageMetadata,
        onSuccess: (Uri) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        if (!file.exists() || file.length() <= 0L) {
            onFailure(IllegalStateException("الملف المحلي غير موجود أو فارغ"))
            return
        }

        val ref = storage.reference.child(path)

        // Upload first, then resolve the download URL with a short retry.
        // Some Storage backends can briefly return OBJECT_NOT_FOUND immediately
        // after a successful upload. Retrying the URL lookup avoids treating a
        // successful upload as a failed upload.
        // Upload the actual bytes instead of a file URI. This avoids URI/provider
        // edge cases on Android devices while keeping the exact Storage path.
        val bytes = try { file.readBytes() } catch (e: Exception) {
            onFailure(IllegalStateException("تعذر قراءة الملف قبل رفعه", e))
            return
        }
        ref.putBytes(bytes, metadata)
            .addOnSuccessListener {
                resolveDownloadUrlWithRetry(ref, path, 5, onSuccess, onFailure)
            }
            .addOnFailureListener { e ->
                val code = (e as? com.google.firebase.storage.StorageException)?.errorCode
                val details = when (code) {
                    com.google.firebase.storage.StorageException.ERROR_NOT_AUTHORIZED -> "صلاحية Storage مرفوضة"
                    com.google.firebase.storage.StorageException.ERROR_BUCKET_NOT_FOUND -> "Firebase Storage غير مهيأ لهذا المشروع"
                    else -> e.message ?: e.javaClass.simpleName
                }
                onFailure(IllegalStateException("Storage: $details | path=$path", e))
            }
    }

    private fun resolveDownloadUrlWithRetry(
        ref: com.google.firebase.storage.StorageReference,
        path: String,
        attemptsLeft: Int,
        onSuccess: (Uri) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        ref.downloadUrl
            .addOnSuccessListener { onSuccess(it) }
            .addOnFailureListener { e ->
                val code = (e as? com.google.firebase.storage.StorageException)?.errorCode
                if (code == com.google.firebase.storage.StorageException.ERROR_OBJECT_NOT_FOUND && attemptsLeft > 1) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        resolveDownloadUrlWithRetry(ref, path, attemptsLeft - 1, onSuccess, onFailure)
                    }, 1000L)
                } else {
                    val details = when (code) {
                        com.google.firebase.storage.StorageException.ERROR_OBJECT_NOT_FOUND -> "الملف غير موجود في Storage بعد الرفع"
                        com.google.firebase.storage.StorageException.ERROR_NOT_AUTHORIZED -> "صلاحية قراءة Storage مرفوضة"
                        com.google.firebase.storage.StorageException.ERROR_BUCKET_NOT_FOUND -> "Firebase Storage غير مهيأ لهذا المشروع"
                        else -> e.message ?: e.javaClass.simpleName
                    }
                    onFailure(IllegalStateException("Storage: $details | path=$path", e))
                }
            }
    }

    private fun uploadChatImage(uri: Uri) {
        val room = currentRoom ?: return
        val peer = currentPeer ?: return
        if (isBlocked) return
        reserveMessageSlot {
            loading = true
            val id = UUID.randomUUID().toString()
            val storagePath = "messages/$room/$id.jpg"
            val compressed = compressImageUri(uri)
            if (compressed == null) { loading = false; showError("تعذر تجهيز الصورة"); return@reserveMessageSlot }
            val metadata = com.google.firebase.storage.StorageMetadata.Builder().setContentType("image/jpeg").build()
            uploadFileAndGetUrl(storagePath, compressed, metadata, { url ->
                val expires = System.currentTimeMillis() + IMAGE_LIFETIME_MS
                val data = mapOf<String, Any>("senderId" to uid, "type" to "image", "text" to "", "imageUrl" to url.toString(), "timestamp" to ServerValue.TIMESTAMP, "expiresAt" to expires, "deliveredAt" to 0L, "readAt" to 0L, "storagePath" to storagePath)
                db.reference.child("rooms").child(room).child("messages").child(id).setValue(data)
                    .addOnSuccessListener { loading = false; compressed.delete(); updateChatPreview(peer, "📷 صورة") }
                    .addOnFailureListener {
                        loading = false
                        compressed.delete()
                        storage.reference.child(storagePath).delete()
                        showError(it.message ?: "فشل إرسال الصورة")
                    }
            }, { error ->
                loading = false
                compressed.delete()
                showError(error.message ?: "فشل رفع الصورة")
            })
        }
    }

    private fun compressImageUri(uri: Uri): File? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1280 || bounds.outHeight / sample > 1280) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 }
            val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val file = File(cacheDir, "compressed-${UUID.randomUUID()}.jpg")
            file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            bitmap.recycle()
            file
        } catch (_: Exception) { null }
    }

    private fun startRecording() {
        if (isRecording) return
        val file = File(cacheDir, "voice-${UUID.randomUUID()}.m4a"); recordingFile = file
        try {
            mediaRecorder = MediaRecorder().apply { setAudioSource(MediaRecorder.AudioSource.MIC); setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setAudioEncodingBitRate(64000); setAudioSamplingRate(44100); setOutputFile(file.absolutePath); prepare(); start() }
            isRecording = true
            Toast.makeText(this, "جاري التسجيل… اضغط الميكروفون مرة أخرى للإرسال", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { mediaRecorder?.release(); mediaRecorder = null; showError(e.message ?: "تعذر بدء التسجيل") }
    }

    private fun stopRecordingAndSend() {
        if (!isRecording) return
        try { mediaRecorder?.stop() } catch (_: Exception) {}
        mediaRecorder?.release(); mediaRecorder = null; isRecording = false
        val file = recordingFile ?: return
        val room = currentRoom ?: return
        val peer = currentPeer ?: return
        reserveMessageSlot {
            loading = true
            val id = UUID.randomUUID().toString()
            val storagePath = "messages/$room/$id.m4a"
            val metadata = com.google.firebase.storage.StorageMetadata.Builder().setContentType("audio/mp4").build()
            uploadFileAndGetUrl(storagePath, file, metadata, { url ->
                val data = mapOf<String, Any>("senderId" to uid, "type" to "audio", "text" to "", "audioUrl" to url.toString(), "timestamp" to ServerValue.TIMESTAMP, "expiresAt" to 0L, "deliveredAt" to 0L, "readAt" to 0L, "storagePath" to storagePath)
                db.reference.child("rooms").child(room).child("messages").child(id).setValue(data)
                    .addOnSuccessListener { loading = false; updateChatPreview(peer, "🎤 تسجيل صوتي"); file.delete(); recordingFile = null }
                    .addOnFailureListener {
                        loading = false
                        storage.reference.child(storagePath).delete()
                        file.delete()
                        recordingFile = null
                        showError(it.message ?: "فشل إرسال التسجيل")
                    }
            }, { error ->
                loading = false
                file.delete()
                showError(error.message ?: "فشل رفع التسجيل")
            })
        }
    }

    private fun playAudio(url: String) {
        try { mediaPlayer?.release(); mediaPlayer = MediaPlayer().apply { setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()); setDataSource(url); setOnPreparedListener { it.start() }; setOnCompletionListener { it.release(); mediaPlayer = null }; prepareAsync() } } catch (e: Exception) { showError(e.message ?: "تعذر تشغيل التسجيل") }
    }

    private fun playMessageSoundIfEnabled(showNotification: Boolean = false) {
        if (uid.isBlank()) return
        val prefs = getSharedPreferences("dardasha_settings", Context.MODE_PRIVATE)
        if (prefs.getBoolean("messageSoundEnabled", true)) {
            try { MediaPlayer.create(this, R.raw.message_chime)?.apply { setOnCompletionListener { it.release() }; start() } } catch (_: Exception) {}
        }
        if (showNotification && prefs.getBoolean("notificationsEnabled", true)) showLocalMessageNotification()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val soundUri = Uri.parse("android.resource://$packageName/${R.raw.message_chime}")
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        val channel = NotificationChannel(NOTIFICATION_CHANNEL_ID, "رسائل دردشة", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "إشعارات الرسائل الجديدة"
            setSound(soundUri, attrs)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun showLocalMessageNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_dardasha)
            .setContentTitle("رسالة جديدة")
            .setContentText("لديك رسالة جديدة في دردشة")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        try { NotificationManagerCompat.from(this).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification) } catch (_: SecurityException) {}
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            if (getSharedPreferences("dardasha_settings", Context.MODE_PRIVATE).getBoolean("notificationsEnabled", true)) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
            }
        }
    }

    private fun deleteForMe(messageId: String) {
        val room = currentRoom ?: return
        db.reference.child("messageDeletes").child(uid).child(room).child(messageId).setValue(true).addOnFailureListener { showError(it.message ?: "تعذر حذف الرسالة لديك") }
    }

    private fun deleteForEveryone(m: Msg) {
        val room = currentRoom ?: return
        if (m.senderId != uid) return
        db.reference.child("rooms").child(room).child("messages").child(m.id).removeValue().addOnSuccessListener {
            if (m.storagePath.isNotBlank()) storage.reference.child(m.storagePath).delete()
        }.addOnFailureListener { showError(it.message ?: "تعذر حذف الرسالة للجميع") }
    }

    private fun blockPeer() {
        val peer = currentPeer ?: return
        db.reference.child("blocks").child(uid).child(peer.uid).setValue(true).addOnSuccessListener { iBlockedPeer = true; isBlocked = true; closeRoom() }.addOnFailureListener { showError(it.message ?: "تعذر حظر المستخدم") }
    }

    private fun unblockPeer() {
        val peer = currentPeer ?: return
        db.reference.child("blocks").child(uid).child(peer.uid).removeValue()
            .addOnSuccessListener { iBlockedPeer = false; checkBlocked() }
            .addOnFailureListener { showError(it.message ?: "تعذر إلغاء الحظر") }
    }

    private fun stopRecordingSilently() {
        try {
            if (isRecording) mediaRecorder?.stop()
        } catch (_: Exception) {
        }
        mediaRecorder?.release()
        mediaRecorder = null
        recordingFile?.delete()
        recordingFile = null
        isRecording = false
    }

    private fun closeRoom() {
        stopRecordingSilently()
        stopTyping()
        waitingListener?.let { db.reference.child("waiting").child(uid).removeEventListener(it) }; waitingListener = null
        messagesListener?.let { currentRoomRef?.removeEventListener(it) }
        currentRoom?.let { room -> messageDeletesListener?.let { db.reference.child("messageDeletes").child(uid).child(room).removeEventListener(it) } }
        currentPeer?.uid?.let { peerId -> typingListener?.let { db.reference.child("typing").child(peerId).removeEventListener(it) } }
        messagesListener = null; messageDeletesListener = null; typingListener = null; currentRoomRef = null; currentRoom = null; currentPeer = null; messages.clear(); deletedMessageIds.clear(); peerTyping = false; messageListenerPrimed = false; isBlocked = false; iBlockedPeer = false; isRecording = false; screen = "main"; selectedTab = 1
    }

    private fun saveName(name: String) {
        val clean = sanitizeDisplayName(name)
        db.reference.child("users").child(uid).child("name").setValue(clean).addOnSuccessListener {
            if (clean == NAME_VIOLATION_REPLACEMENT) showError("تم حذف الاسم للمخالفة")
            loadProfileOrSetup()
        }.addOnFailureListener { showError(it.message ?: "تعذر حفظ الاسم") }
    }

    private fun uploadPendingAvatar(uri: Uri) {
        if (uid.isBlank()) { showError("سجل الدخول أولًا"); return }
        val compressed = compressImageUri(uri)
        if (compressed == null) { showError("تعذر تجهيز الصورة"); return }
        val storagePath = "pendingAvatars/$uid-${UUID.randomUUID()}.jpg"
        val metadata = com.google.firebase.storage.StorageMetadata.Builder().setContentType("image/jpeg").build()
        loading = true
        uploadFileAndGetUrl(storagePath, compressed, metadata, { url ->
            db.reference.child("users").child(uid).updateChildren(mapOf("avatarPendingUrl" to url.toString(), "avatarPendingStoragePath" to storagePath, "avatarPending" to true))
                .addOnSuccessListener { loading = false; compressed.delete(); loadProfileOrSetup(); showError("تم رفع الصورة وهي الآن بانتظار موافقة الأدمن") }
                .addOnFailureListener { loading = false; compressed.delete(); showError(it.message ?: "تم رفع الصورة لكن تعذر حفظ طلب المراجعة") }
        }, { error ->
            loading = false
            compressed.delete()
            showError("فشل رفع الصورة: ${error.message ?: "تحقق من تفعيل Firebase Storage ونشر Storage Rules"}")
        })
    }

    private fun approveAvatar(u: UserProfile) {
        if (u.avatarPendingUrl.isBlank() || u.avatarPendingStoragePath.isBlank() || !u.avatarPendingStoragePath.startsWith("pendingAvatars/${u.uid}-")) { showError("طلب الصورة غير صالح"); return }
        db.reference.child("users").child(u.uid).updateChildren(mapOf("avatarUrl" to u.avatarPendingUrl, "avatarStoragePath" to u.avatarPendingStoragePath, "avatarPending" to false, "avatarPendingUrl" to "", "avatarPendingStoragePath" to ""))
            .addOnFailureListener { showError(it.message ?: "تعذر قبول الصورة") }
    }
    private fun rejectAvatar(u: UserProfile) {
        val pendingUrl = u.avatarPendingUrl
        val pendingPath = u.avatarPendingStoragePath
        db.reference.child("users").child(u.uid).updateChildren(mapOf("avatarPending" to false, "avatarPendingUrl" to "", "avatarPendingStoragePath" to ""))
            .addOnSuccessListener {
                if (pendingPath.isNotBlank()) storage.reference.child(pendingPath).delete() else extractStoragePath(pendingUrl)?.let { storage.reference.child(it).delete() }
            }
            .addOnFailureListener { showError(it.message ?: "تعذر رفض الصورة") }
    }
    private fun setVerified(targetUid: String, value: Boolean) {
        db.reference.child("users").child(targetUid).child("verified").setValue(value)
            .addOnFailureListener { showError(it.message ?: "تعذر تغيير التوثيق") }
    }
    private fun setBanned(targetUid: String, value: Boolean) {
        if (targetUid == OWNER_UID) { showError("لا يمكن حظر مالك التطبيق"); return }
        db.reference.child("users").child(targetUid).child("banned").setValue(value)
            .addOnSuccessListener { if (value) db.reference.child("users").child(targetUid).child("online").setValue(false) }
            .addOnFailureListener { showError(it.message ?: "تعذر تغيير الحظر") }
    }

    private fun extractStoragePath(downloadUrl: String): String? {
        return try {
            val uri = Uri.parse(downloadUrl)
            val encoded = uri.path?.substringAfter("/o/") ?: return null
            java.net.URLDecoder.decode(encoded, "UTF-8")
        } catch (_: Exception) {
            null
        }
    }
    private fun deleteUserData(u: UserProfile) {
        if (u.uid == uid || u.admin || u.uid == OWNER_UID) return
        db.reference.child("users").child(u.uid).removeValue()
        db.reference.child("userChats").child(u.uid).removeValue()
        db.reference.child("blocks").child(u.uid).removeValue()
    }

    private fun logout() {
        setPresence(false); cleanup(); auth.signOut(); uid = ""; profile = null; screen = "login"; selectedTab = 0
    }

    private fun parseUser(s: DataSnapshot): UserProfile? {
        if (!s.exists()) return null
        return UserProfile(
            uid = s.key ?: s.child("uid").getValue(String::class.java).orEmpty(),
            name = s.child("name").getValue(String::class.java).orEmpty(),
            email = s.child("email").getValue(String::class.java).orEmpty(),
            gender = s.child("gender").getValue(String::class.java).orEmpty(),
            avatarUrl = s.child("avatarUrl").getValue(String::class.java).orEmpty(),
            avatarPendingUrl = s.child("avatarPendingUrl").getValue(String::class.java).orEmpty(),
            avatarPending = s.child("avatarPending").getValue(Boolean::class.java) ?: false,
            avatarStoragePath = s.child("avatarStoragePath").getValue(String::class.java).orEmpty(),
            avatarPendingStoragePath = s.child("avatarPendingStoragePath").getValue(String::class.java).orEmpty(),
            verified = s.child("verified").getValue(Boolean::class.java) ?: false,
            admin = (s.key == OWNER_UID),
            banned = s.child("banned").getValue(Boolean::class.java) ?: false,
            online = s.child("online").getValue(Boolean::class.java) ?: false,
            joinedAt = s.child("joinedAt").getValue(Long::class.java) ?: 0L,
            lastSeen = s.child("lastSeen").getValue(Long::class.java) ?: 0L,
            manualOffline = s.child("manualOffline").getValue(Boolean::class.java) ?: false
        )
    }

    private fun cleanup() {
        usersListener?.let { db.reference.child("users").removeEventListener(it) }
        chatsListener?.let { db.reference.child("userChats").child(uid).removeEventListener(it) }
        stopTyping()
        messagesListener?.let { currentRoomRef?.removeEventListener(it) }
        currentRoom?.let { room -> messageDeletesListener?.let { db.reference.child("messageDeletes").child(uid).child(room).removeEventListener(it) } }
        currentPeer?.uid?.let { peerId -> typingListener?.let { db.reference.child("typing").child(peerId).removeEventListener(it) } }
        waitingListener?.let { db.reference.child("waiting").child(uid).removeEventListener(it) }
        usersListener = null; chatsListener = null; messagesListener = null; messageDeletesListener = null; typingListener = null; currentRoomRef = null; waitingListener = null
        onlineUsers.clear(); chats.clear(); messages.clear(); deletedMessageIds.clear(); unreadInitialized = false; lastUnreadTotal = 0
    }

    private fun showError(msg: String) { errorText = msg; Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    private fun peerStatusText(peer: UserProfile?): String {
        if (peer == null) return ""
        if (peer.online && !peer.manualOffline) return "متصل الآن"
        if (peer.manualOffline || peer.lastSeen <= 0L) return "غير متصل"
        return "آخر ظهور ${formatDateTime(peer.lastSeen)}"
    }

    private fun formatDateTime(ts: Long): String {
        if (ts <= 0) return ""
        val d = java.text.SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        return d.format(java.util.Date(ts))
    }

    private fun formatTime(ts: Long): String { if (ts <= 0) return ""; val d = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()); return d.format(java.util.Date(ts)) }
}

@Composable
private fun DardashaTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(primary = Pink, secondary = Purple, tertiary = Blue, background = Bg, surface = Panel, onBackground = TextMain, onSurface = TextMain)
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
