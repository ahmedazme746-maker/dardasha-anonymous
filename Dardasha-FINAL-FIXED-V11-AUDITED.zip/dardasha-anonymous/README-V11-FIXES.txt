Dardasha V11 / version 6.0

This version includes a real audit of the previous V9/V10 changes.

Fixed in source:
- Storage upload now uses the Firebase bucket configured by google-services.json; no silent fallback to a different bucket.
- Upload verifies object metadata before requesting downloadUrl and reports bucket/path on failure.
- Profile images, chat images and voice recordings use the same verified upload flow.
- Back on the main screen no longer calls finish(); chat/settings/edit/password/admin return to the previous app screen.
- Existing current-user offensive names are automatically sanitized on profile load.
- Database root-wide read permission removed; child rules remain responsible for access.
- Version bumped to 6.0 / versionCode 7.

Firebase requirements:
1) Storage must be initialized in Firebase Console and the Storage Rules in storage.rules must be deployed.
2) The current default bucket format is PROJECT_ID.firebasestorage.app. This project config says dardasha-anonymous.firebasestorage.app.
3) Google login still requires enabling Google provider, adding SHA-1, and downloading a new google-services.json containing the OAuth web client.
4) database.rules.json must be deployed separately; the Android build does not deploy rules automatically.

Owner UID remains exactly:
wDMqt8jpP1gEJJtLuUMrTTaeU8q1
