Dardasha Anonymous V9

This version fixes the source-level issues identified in V8:
- Real Google sign-in code using Firebase + Credential Manager (requires Google provider/OAuth setup and a refreshed google-services.json).
- Real Online/Offline switch in Profile and Settings.
- Offline users are excluded from Active Now and do not expose last-seen.
- Active Now rows open direct chats; each user self-registers as a room member.
- Typing indicator.
- Delivered/read check marks.
- Delete for me / delete for everyone.
- Clickable http/https links in text messages.
- In-app message sound + notification channel.
- Profile and chat image upload with compression and MIME metadata.
- Voice recording upload with MIME metadata.
- Name moderation replacement.
- Stronger room membership rules.
- Notification permission on Android 13+.

IMPORTANT FIREBASE SETUP:
1) Deploy database.rules.json to Realtime Database Rules.
2) Deploy storage.rules to Cloud Storage Rules.
3) For Google login, enable Google provider, add SHA-1, then download the NEW google-services.json and replace the project file. Firebase's current Android docs require the OAuth client information for Google sign-in.
