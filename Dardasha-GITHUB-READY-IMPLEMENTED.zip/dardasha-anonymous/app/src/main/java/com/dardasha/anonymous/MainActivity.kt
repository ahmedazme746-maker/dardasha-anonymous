@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.dardasha.anonymous

import android.Manifest
import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.delay
import java.io.File
import java.util.UUID

private const val DB_URL = "https://dardasha-anonymous-default-rtdb.firebaseio.com"
private const val MAX_MESSAGE_LENGTH = 1000
private const val IMAGE_LIFETIME_MS = 3 * 60 * 1000L
private const val HEARTBEAT_MS = 30_000L
private const val OWNER_EMAIL = "ahmedazme746@gmail.com"
private const val ONLINE_TIMEOUT_MS = 90_000L

private val Bg = Color(0xFF070617)
private val Panel = Color(0xFF111128)
private val Panel2 = Color(0xFF171637)
private val Purple = Color(0xFF8B35FF)
private val Violet = Color(0xFF6A22E8)
private val Pink = Color(0xFFFF4FD8)
private val TextMain = Color(0xFFF7F3FF)
private val TextMuted = Color(0xFFB9B2D0)
private val Green = Color(0xFF20E070)
private val Blue = Color(0xFF4EA7FF)
private val Red = Color(0xFFFF5577)

private val MainGradient = Brush.horizontalGradient(listOf(Purple, Pink))
private val SoftGradient = Brush.linearGradient(listOf(Color(0xFF32136B), Color(0xFF14142E)))

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val gender: String = "",
    val avatarUrl: String = "",
    val avatarPendingUrl: String = "",
    val avatarPending: Boolean = false,
    val verified: Boolean = false,
    val admin: Boolean = false,
    val banned: Boolean = false,
    val online: Boolean = false,
    val joinedAt: Long = 0L,
    val lastSeen: Long = 0L
)

data class Msg(
    val id: String,
    val senderId: String,
    val type: String,
    val text: String,
    val imageUrl: String,
    val audioUrl: String,
    val timestamp: Long,
    val expiresAt: Long
)

data class Report(
    val id: String = "",
    val reporterId: String = "",
    val targetId: String = "",
    val roomId: String = "",
    val reason: String = "",
    val createdAt: Long = 0L
)

data class ChatPreview(
    val roomId: String,
    val peerId: String,
    val peerName: String,
    val peerVerified: Boolean,
    val peerAvatar: String,
    val lastMessage: String,
    val updatedAt: Long
)

class MainActivity : ComponentActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseDatabase
    private lateinit var storage: FirebaseStorage

    private var uid by mutableStateOf("")
    private var profile by mutableStateOf<UserProfile?>(null)
    private var screen by mutableStateOf("login")
    private var selectedTab by mutableStateOf(0)
    private var loading by mutableStateOf(false)
    private var errorText by mutableStateOf<String?>(null)
    private var isRecording by mutableStateOf(false)
    private var now by mutableStateOf(System.currentTimeMillis())
    private var isBlocked by mutableStateOf(false)

    private val messages = mutableStateListOf<Msg>()
    private val onlineUsers = mutableStateListOf<UserProfile>()
    private val chats = mutableStateListOf<ChatPreview>()
    private var currentRoom by mutableStateOf<String?>(null)
    private var currentPeer by mutableStateOf<UserProfile?>(null)

    private var usersListener: ValueEventListener? = null
    private var chatsListener: ValueEventListener? = null
    private var messagesListener: ChildEventListener? = null
    private var currentRoomRef: DatabaseReference? = null
    private var waitingListener: ValueEventListener? = null
    private var mediaRecorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private var mediaPlayer: MediaPlayer? = null
    private val heartbeatHandler = Handler(Looper.getMainLooper())
    private var connected = false
    private var foreground = false
    private var connectionListener: ValueEventListener? = null

    private val heartbeat = object : Runnable {
        override fun run() {
            if (uid.isNotBlank() && connected && foreground) {
                db.reference.child("users").child(uid).updateChildren(
                    mapOf("online" to true, "lastSeen" to ServerValue.TIMESTAMP)
                )
            }
            heartbeatHandler.postDelayed(this, HEARTBEAT_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        db = FirebaseDatabase.getInstance(DB_URL)
        storage = FirebaseStorage.getInstance()
        now = System.currentTimeMillis()
        watchConnection()

        val current = auth.currentUser
        if (current != null) {
            uid = current.uid
            loadProfileOrSetup()
        }

        setContent {
            DardashaTheme { Surface(Modifier.fillMaxSize(), color = Bg) { App() } }
        }

        heartbeatHandler.post(heartbeat)
    }

    override fun onStart() {
        super.onStart()
        foreground = true
        if (uid.isNotBlank()) setPresence(true)
    }

    override fun onStop() {
        foreground = false
        if (uid.isNotBlank()) setPresence(false)
        super.onStop()
    }

    override fun onDestroy() {
        heartbeatHandler.removeCallbacks(heartbeat)
        connectionListener?.let { db.reference.child(".info").child("connected").removeEventListener(it) }
        connectionListener = null
        mediaPlayer?.release()
        mediaPlayer = null
        super.onDestroy()
    }

    private fun watchConnection() {
        val ref = db.reference.child(".info").child("connected")
        connectionListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                connected = snapshot.getValue(Boolean::class.java) == true
                if (connected && foreground && uid.isNotBlank()) setPresence(true)
            }
            override fun onCancelled(error: DatabaseError) { connected = false }
        }
        ref.addValueEventListener(connectionListener!!)
    }

    private fun isOwnerAccount(): Boolean =
        auth.currentUser?.email?.equals(OWNER_EMAIL, ignoreCase = true) == true

    @Composable
    private fun App() {
        LaunchedEffect(Unit) {
            while (true) {
                now = System.currentTimeMillis()
                delay(1_000)
            }
        }
        when (screen) {
            "login" -> LoginScreen()
            "guest" -> GuestScreen()
            "register" -> RegisterScreen()
            "main" -> MainScreen()
            "chat" -> ChatScreen()
            "admin" -> AdminScreen()
            "edit" -> EditProfileScreen()
            else -> LoginScreen()
        }
    }

    @Composable
    private fun DardashaLogo(size: Int = 92) {
        Box(
            Modifier.size(size.dp).shadow(16.dp, CircleShape).background(MainGradient, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.FavoriteBorder, null, tint = Color.White, modifier = Modifier.size((size * .55).dp))
        }
    }

    @Composable
    private fun ScreenBackground(content: @Composable BoxScope.() -> Unit) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF09071A), Color(0xFF070617), Color(0xFF0D0820)))
            ),
            content = content
        )
    }

    @Composable
    private fun GradientButton(
        text: String,
        onClick: () -> Unit,
        modifier: Modifier = Modifier,
        enabled: Boolean = true,
        icon: @Composable (() -> Unit)? = null
    ) {
        Box(
            modifier
                .height(54.dp)
                .clip(RoundedCornerShape(17.dp))
                .background(if (enabled) MainGradient else Brush.linearGradient(listOf(Color.DarkGray, Color.Gray)))
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) { icon(); Spacer(Modifier.width(9.dp)) }
                Text(text, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }

    @Composable
    private fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
        Column(
            modifier
                .clip(RoundedCornerShape(22.dp))
                .background(SoftGradient)
                .border(1.dp, Color(0xFF3C2A69), RoundedCornerShape(22.dp))
                .padding(18.dp),
            content = content
        )
    }

    @Composable
    private fun AuthHeader(title: String, subtitle: String) {
        DardashaLogo()
        Spacer(Modifier.height(18.dp))
        Text(title, style = MaterialTheme.typography.headlineLarge, color = TextMain, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color = TextMuted, textAlign = TextAlign.Center)
    }

    @Composable
    private fun AuthField(value: String, onValueChange: (String) -> Unit, label: String, icon: @Composable () -> Unit, password: Boolean = false) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text(label) },
            leadingIcon = icon,
            visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Panel2,
                unfocusedContainerColor = Panel,
                focusedBorderColor = Pink,
                unfocusedBorderColor = Color(0xFF363052),
                focusedLabelColor = Pink,
                unfocusedLabelColor = TextMuted,
                focusedTextColor = TextMain,
                unfocusedTextColor = TextMain,
                cursorColor = Pink,
                focusedLeadingIconColor = Pink,
                unfocusedLeadingIconColor = TextMuted
            )
        )
    }

    @Composable
    private fun LoginScreen() {
        var email by remember { mutableStateOf("") }
        var password by remember { mutableStateOf("") }
        ScreenBackground {
            Column(
                Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                AuthHeader("دردشة", "تواصل مع أشخاص جدد")
                Spacer(Modifier.height(25.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    AuthField(email, { email = it }, "البريد الإلكتروني", { Icon(Icons.Outlined.Email, null) })
                    Spacer(Modifier.height(12.dp))
                    AuthField(password, { password = it }, "كلمة المرور", { Icon(Icons.Outlined.Lock, null) }, true)
                    TextButton({ resetPassword(email) }, Modifier.align(Alignment.End)) { Text("نسيت كلمة المرور؟", color = TextMuted) }
                    GradientButton("تسجيل الدخول", { login(email, password) }, Modifier.fillMaxWidth(), !loading && email.isNotBlank() && password.isNotBlank(), { Icon(Icons.Default.Login, null) })
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        HorizontalDivider(Modifier.weight(1f), color = Color(0xFF3A3355)); Text("  أو  ", color = TextMuted); HorizontalDivider(Modifier.weight(1f), color = Color(0xFF3A3355))
                    }
                    Spacer(Modifier.height(14.dp))
                    OutlinedButton({ showError("تسجيل Google يحتاج ربط OAuth من Firebase قبل تفعيله") }, Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain)) {
                        Text("G  المتابعة عبر Google", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton({ screen = "guest" }, Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain)) { Text("دخول كزائر") }
                    TextButton({ screen = "register" }, Modifier.fillMaxWidth()) { Text("ليس لديك حساب؟ إنشاء حساب", color = Pink, fontWeight = FontWeight.Bold) }
                }
                ErrorText()
            }
        }
    }

    @Composable
    private fun GuestScreen() {
        var name by remember { mutableStateOf("") }
        var gender by remember { mutableStateOf("") }
        ScreenBackground {
            Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                AuthHeader("دخول كزائر", "ابدأ الدردشة الآن بدون تسجيل")
                Spacer(Modifier.height(24.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    AuthField(name, { name = it }, "الاسم المستعار", { Icon(Icons.Outlined.Person, null) })
                    Spacer(Modifier.height(15.dp))
                    Text("اختر الجنس (لا يمكن تغييره لاحقًا)", color = TextMuted, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(10.dp))
                    GenderChoice(gender) { gender = it }
                    Spacer(Modifier.height(18.dp))
                    GradientButton("دخول كزائر", { createGuestProfile(name, gender) }, Modifier.fillMaxWidth(), !loading && name.trim().isNotEmpty() && gender.isNotBlank(), { Icon(Icons.Default.Login, null) })
                    TextButton({ screen = "login" }, Modifier.fillMaxWidth()) { Text("رجوع", color = TextMuted) }
                }
                ErrorText()
            }
        }
    }

    @Composable
    private fun RegisterScreen() {
        var name by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var password by remember { mutableStateOf("") }
        var gender by remember { mutableStateOf("") }
        ScreenBackground {
            Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                AuthHeader("إنشاء حساب", "انضم إلينا وكن جزءًا من مجتمع الدردشة")
                Spacer(Modifier.height(20.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    AuthField(name, { name = it }, "الاسم المستعار", { Icon(Icons.Outlined.Person, null) })
                    Spacer(Modifier.height(10.dp))
                    AuthField(email, { email = it }, "البريد الإلكتروني", { Icon(Icons.Outlined.Email, null) })
                    Spacer(Modifier.height(10.dp))
                    AuthField(password, { password = it }, "كلمة المرور", { Icon(Icons.Outlined.Lock, null) }, true)
                    Spacer(Modifier.height(15.dp))
                    Text("اختر الجنس (لا يمكن تغييره لاحقًا)", color = TextMuted, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(10.dp))
                    GenderChoice(gender) { gender = it }
                    Spacer(Modifier.height(18.dp))
                    GradientButton("إنشاء الحساب", { register(name, email, password, gender) }, Modifier.fillMaxWidth(), !loading && name.trim().isNotEmpty() && email.contains("@") && password.length >= 6 && gender.isNotBlank(), { Icon(Icons.Default.PersonAdd, null) })
                    TextButton({ screen = "login" }, Modifier.fillMaxWidth()) { Text("لديك حساب؟ تسجيل الدخول", color = Pink) }
                }
                ErrorText()
            }
        }
    }

    @Composable
    private fun MainScreen() {
        val tabs = listOf("عشوائي", "الرسائل", "نشط الآن", "ملفي")
        val icons = listOf(Icons.Outlined.Shuffle, Icons.Outlined.Email, Icons.Outlined.People, Icons.Outlined.Person)
        Scaffold(
            containerColor = Bg,
            topBar = {
                Row(Modifier.fillMaxWidth().background(Color(0xFF0A091B)).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).background(MainGradient, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.FavoriteBorder, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
                        Spacer(Modifier.width(10.dp)); Text("دردشة", color = TextMain, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                    }
                    if (profile?.admin == true) IconButton({ screen = "admin" }) { Icon(Icons.Outlined.AdminPanelSettings, "الإدارة", tint = Pink) }
                    IconButton({ loadProfileOrSetup() }) { Icon(Icons.Default.Refresh, "تحديث", tint = TextMain) }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0D0B20)) {
                    tabs.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = selectedTab == i,
                            onClick = { selectedTab = i },
                            icon = { Icon(icons[i], null) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Pink, selectedTextColor = Pink, indicatorColor = Color(0xFF2A1549), unselectedIconColor = TextMuted, unselectedTextColor = TextMuted)
                        )
                    }
                }
            }
        ) { p ->
            Box(Modifier.fillMaxSize().padding(p)) {
                when (selectedTab) { 0 -> RandomScreen(); 1 -> MessagesScreen(); 2 -> OnlineScreen(); 3 -> ProfileScreen() }
            }
        }
    }

    @Composable
    private fun RandomScreen() {
        ScreenBackground {
            Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.offset((-18).dp, 8.dp).size(90.dp).background(Color(0xFF6A25E8), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.ChatBubble, null, tint = Color.White, modifier = Modifier.size(48.dp)) }
                    Box(Modifier.offset(28.dp, (-8).dp).size(86.dp).background(Pink, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Chat, null, tint = Color.White, modifier = Modifier.size(44.dp)) }
                }
                Spacer(Modifier.height(20.dp))
                Text("ابحث عن أشخاص جدد", style = MaterialTheme.typography.headlineMedium, color = TextMain, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text("ابدأ محادثة عشوائية مع شخص متصل الآن", color = TextMuted, textAlign = TextAlign.Center)
                Spacer(Modifier.height(28.dp))
                GradientButton("ابدأ محادثة عشوائية", { startMatching() }, Modifier.fillMaxWidth(), !loading, { Icon(Icons.Default.Shuffle, null) })
                if (loading) { Spacer(Modifier.height(12.dp)); CircularProgressIndicator(color = Pink) }
                ErrorText()
            }
        }
    }

    @Composable
    private fun MessagesScreen() {
        ScreenBackground {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("الرسائل", style = MaterialTheme.typography.headlineSmall, color = TextMain, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.Search, null, tint = TextMuted)
                }
                if (chats.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد محادثات حتى الآن", color = TextMuted) }
                else LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                    items(chats.sortedByDescending { it.updatedAt }, key = { it.roomId }) { c ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).clickable { openRoom(c.roomId, c.peerId) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(c.peerName, c.peerVerified, c.peerAvatar, null, Modifier.size(54.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) { Row(verticalAlignment = Alignment.CenterVertically) { Text(c.peerName, color = TextMain, fontWeight = FontWeight.Bold); if (c.peerVerified) VerifiedBadge() }; Text(c.lastMessage.ifBlank { "محادثة" }, color = TextMuted, maxLines = 1) }
                            Text(formatTime(c.updatedAt), color = TextMuted, style = MaterialTheme.typography.labelSmall)
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }

    @Composable
    private fun OnlineScreen() {
        val fresh = onlineUsers.filter { it.online && (it.uid == uid || (it.lastSeen > 0L && now - it.lastSeen <= ONLINE_TIMEOUT_MS)) }
        val admin = fresh.firstOrNull { it.admin }
        val others = fresh.filterNot { it.admin }.sortedByDescending { it.joinedAt }
        ScreenBackground {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("نشط الآن", style = MaterialTheme.typography.headlineSmall, color = TextMain, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    Text("${fresh.size} متصل", color = Green, fontWeight = FontWeight.Bold)
                }
                if (fresh.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا يوجد مستخدمون نشطون الآن", color = TextMuted) }
                else LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                    if (admin != null) item(key = "admin") { OnlineRow(admin, true); Spacer(Modifier.height(8.dp)) }
                    items(others, key = { it.uid }) { u -> OnlineRow(u, false); Spacer(Modifier.height(8.dp)) }
                }
            }
        }
    }

    @Composable
    private fun OnlineRow(u: UserProfile, admin: Boolean) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (admin) Color(0xFF25123E) else Panel).border(if (admin) 1.dp else 0.dp, if (admin) Color(0xFF7A3DE8) else Color.Transparent, RoundedCornerShape(18.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(u.name, u.verified || admin, u.avatarUrl, u.gender, Modifier.size(54.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text(u.name, color = TextMain, fontWeight = FontWeight.Bold); if (u.verified || admin) VerifiedBadge(); if (admin) { Spacer(Modifier.width(4.dp)); AdminBadge() } }
                Text(if (admin) "متصل الآن • الإدارة" else "متصل الآن", color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
            Box(Modifier.size(11.dp).background(Green, CircleShape))
        }
    }

    @Composable
    private fun ProfileScreen() {
        val u = profile
        ScreenBackground {
            Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { IconButton({}) { Icon(Icons.Default.ArrowBack, null, tint = TextMain) }; Text("الملف الشخصي", color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold) }
                Spacer(Modifier.height(8.dp))
                Avatar(u?.name ?: "مستخدم", u?.verified == true || u?.admin == true, u?.avatarUrl, u?.gender, Modifier.size(122.dp))
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Text(u?.name ?: "", color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold); if (u?.verified == true || u?.admin == true) VerifiedBadge() }
                if (u?.admin == true) { Spacer(Modifier.height(4.dp)); AdminBadge() }
                Text(u?.email?.ifBlank { "حساب زائر" } ?: "", color = TextMuted)
                Spacer(Modifier.height(20.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    ProfileRow(Icons.Outlined.Edit, "تعديل الملف الشخصي") { screen = "edit" }
                    ProfileRow(Icons.Outlined.Lock, "تغيير كلمة المرور") { showError("استخدم إعادة تعيين كلمة المرور من شاشة تسجيل الدخول") }
                    ProfileRow(Icons.Outlined.Settings, "الإعدادات") { showError("الإعدادات الأساسية جاهزة، وسنضيف إعدادات الإشعارات لاحقًا") }
                    if (u?.admin == true) ProfileRow(Icons.Outlined.AdminPanelSettings, "لوحة تحكم الأدمن") { screen = "admin" }
                    ProfileRow(Icons.Outlined.Logout, "تسجيل الخروج", Red) { logout() }
                }
            }
        }
    }

    @Composable
    private fun ProfileRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, tint: Color = TextMain, action: () -> Unit) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = action).padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = tint); Spacer(Modifier.width(12.dp)); Text(title, color = tint, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronLeft, null, tint = TextMuted)
        }
    }

    @Composable
    private fun EditProfileScreen() {
        var name by remember { mutableStateOf(profile?.name ?: "") }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) uploadPendingAvatar(uri) }
        ScreenBackground {
            Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { IconButton({ screen = "main" }) { Icon(Icons.Default.ArrowBack, null, tint = TextMain) }; Text("تعديل الملف الشخصي", color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold) }
                Spacer(Modifier.height(20.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Avatar(profile?.name ?: "مستخدم", profile?.verified == true, profile?.avatarPendingUrl.takeIf { profile?.avatarPending == true } ?: profile?.avatarUrl, profile?.gender, Modifier.size(120.dp)) }
                Spacer(Modifier.height(12.dp))
                GradientButton("اختيار صورة", { launcher.launch("image/*") }, Modifier.fillMaxWidth(), !loading, { Icon(Icons.Default.PhotoCamera, null) })
                if (profile?.avatarPending == true) { Spacer(Modifier.height(8.dp)); Text("الصورة بانتظار موافقة الأدمن ولن تظهر للعامة قبل الموافقة.", color = Pink, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
                Spacer(Modifier.height(18.dp))
                AuthField(name, { name = it }, "الاسم", { Icon(Icons.Outlined.Person, null) })
                Spacer(Modifier.height(10.dp))
                Text("الجنس: ${if (profile?.gender == "female") "أنثى" else "ذكر"} • لا يمكن تغييره بعد الاختيار", color = TextMuted)
                Spacer(Modifier.height(18.dp))
                GradientButton("حفظ", { saveName(name) }, Modifier.fillMaxWidth(), name.trim().isNotEmpty())
                ErrorText()
            }
        }
    }

    @Composable
    private fun AdminScreen() {
        var users by remember { mutableStateOf<List<UserProfile>>(emptyList()) }
        var reports by remember { mutableStateOf<List<Report>>(emptyList()) }
        ScreenBackground {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { IconButton({ screen = "main" }) { Icon(Icons.Default.ArrowBack, null, tint = TextMain) }; Text("لوحة تحكم الأدمن", color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold) }
                Text("صلاحيات كاملة: إدارة المستخدمين • التوثيق • الصور • الحظر", color = TextMuted, modifier = Modifier.padding(horizontal = 18.dp))
                Spacer(Modifier.height(10.dp))
                LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
                    item { AdminSectionTitle("المستخدمون") }
                    items(users.sortedWith(compareByDescending<UserProfile> { it.admin }.thenByDescending { it.joinedAt }), key = { it.uid }) { u -> AdminUserCard(u) }
                    item { Spacer(Modifier.height(18.dp)); AdminSectionTitle("البلاغات") }
                    if (reports.isEmpty()) item { Text("لا توجد بلاغات جديدة", color = TextMuted, modifier = Modifier.padding(vertical = 10.dp)) }
                    items(reports, key = { it.id }) { r ->
                        GlassCard(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Text("بلاغ من: ${r.reporterId}", color = TextMain, fontWeight = FontWeight.Bold)
                            Text("على المستخدم: ${r.targetId}", color = TextMuted)
                            Text("السبب: ${r.reason}", color = Pink)
                            Text(formatTime(r.createdAt), color = TextMuted, style = MaterialTheme.typography.labelSmall)
                            Spacer(Modifier.height(6.dp))
                            OutlinedButton({ db.reference.child("reports").child(r.id).removeValue() }) { Text("تمت المراجعة") }
                        }
                    }
                }
            }
        }
        DisposableEffect(uid) {
            val ref = db.reference.child("users")
            val listener = object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) { users = s.children.mapNotNull { parseUser(it) } }
                override fun onCancelled(e: DatabaseError) { showError(e.message) }
            }
            val reportsRef = db.reference.child("reports")
            val reportsListener = object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    reports = s.children.map { snap ->
                        Report(
                            id = snap.key.orEmpty(),
                            reporterId = snap.child("reporterId").getValue(String::class.java).orEmpty(),
                            targetId = snap.child("targetId").getValue(String::class.java).orEmpty(),
                            roomId = snap.child("roomId").getValue(String::class.java).orEmpty(),
                            reason = snap.child("reason").getValue(String::class.java).orEmpty(),
                            createdAt = snap.child("createdAt").getValue(Long::class.java) ?: 0L
                        )
                    }.sortedByDescending { it.createdAt }
                }
                override fun onCancelled(e: DatabaseError) { showError(e.message) }
            }
            ref.addValueEventListener(listener)
            reportsRef.addValueEventListener(reportsListener)
            onDispose { ref.removeEventListener(listener); reportsRef.removeEventListener(reportsListener) }
        }
    }

    @Composable
    private fun AdminSectionTitle(text: String) { Text(text, color = Pink, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 8.dp)) }

    @Composable
    private fun AdminUserCard(u: UserProfile) {
        GlassCard(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(u.name, u.verified || u.admin, u.avatarUrl, u.gender, Modifier.size(52.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Row(verticalAlignment = Alignment.CenterVertically) { Text(u.name, color = TextMain, fontWeight = FontWeight.Bold); if (u.verified) VerifiedBadge(); if (u.admin) AdminBadge() }; Text(u.email.ifBlank { "زائر" }, color = TextMuted, maxLines = 1) }
            }
            Spacer(Modifier.height(10.dp))
            if (u.avatarPending && u.avatarPendingUrl.isNotBlank()) {
                Text("صورة جديدة بانتظار المراجعة", color = Pink, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(7.dp))
                AsyncImage(u.avatarPendingUrl, "الصورة المعلقة", Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.Crop)
                Spacer(Modifier.height(7.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    GradientButton("قبول الصورة", { approveAvatar(u) }, Modifier.weight(1f), true, { Icon(Icons.Default.Check, null) })
                    OutlinedButton({ rejectAvatar(u) }, Modifier.weight(1f)) { Text("رفض") }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton({ setVerified(u.uid, !u.verified) }, Modifier.weight(1f)) { Text(if (u.verified) "إلغاء التوثيق" else "توثيق ✓") }
                OutlinedButton({ setBanned(u.uid, !u.banned) }, Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = if (u.banned) Green else Red)) { Text(if (u.banned) "إلغاء الحظر" else "حظر") }
            }
            if (!u.admin) {
                Spacer(Modifier.height(6.dp))
                OutlinedButton({ deleteUserData(u) }, Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) {
                    Icon(Icons.Default.DeleteForever, null)
                    Spacer(Modifier.width(6.dp))
                    Text("حذف بيانات المستخدم")
                }
            }
        }
    }

    @Composable
    private fun ChatScreen() {
        val peer = currentPeer
        var text by remember(currentRoom) { mutableStateOf("") }
        var menu by remember { mutableStateOf(false) }
        val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) uploadChatImage(uri) }
        val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) startRecording() else showError("نحتاج إذن الميكروفون لإرسال تسجيل صوتي") }
        ScreenBackground {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().background(Color(0xFF0A091B)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ closeRoom() }) { Icon(Icons.Default.ArrowBack, null, tint = TextMain) }
                    Avatar(peer?.name ?: "مستخدم", peer?.verified == true, peer?.avatarUrl, peer?.gender, Modifier.size(42.dp))
                    Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f)) { Row(verticalAlignment = Alignment.CenterVertically) { Text(peer?.name ?: "مستخدم", color = TextMain, fontWeight = FontWeight.Bold); if (peer?.verified == true) VerifiedBadge() }; Text(if (peer?.online == true) "متصل الآن" else "غير متصل", color = if (peer?.online == true) Green else TextMuted, style = MaterialTheme.typography.labelSmall) }
                    IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, null, tint = TextMain) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("حظر المستخدم") }, onClick = { menu = false; blockPeer() }, leadingIcon = { Icon(Icons.Default.Block, null) })
                        DropdownMenuItem(text = { Text("إبلاغ عن المستخدم") }, onClick = { menu = false; reportPeer() }, leadingIcon = { Icon(Icons.Default.Flag, null) })
                    }
                }
                if (isBlocked) Box(Modifier.fillMaxWidth().background(Color(0xFF341126)).padding(10.dp), contentAlignment = Alignment.Center) { Text("تم حظر هذا المستخدم", color = Red, fontWeight = FontWeight.Bold) }
                LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(10.dp)) {
                    items(messages.filter { it.type != "image" || it.expiresAt == 0L || it.expiresAt > now }, key = { it.id }) { m -> MessageBubble(m) }
                }
                Row(Modifier.fillMaxWidth().background(Color(0xFF0A091B)).padding(8.dp).navigationBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ imageLauncher.launch("image/*") }, enabled = !isBlocked) { Icon(Icons.Default.CameraAlt, "صورة", tint = Pink) }
                    IconButton({ if (isRecording) stopRecordingAndSend() else micLauncher.launch(Manifest.permission.RECORD_AUDIO) }, enabled = !isBlocked) { Icon(if (isRecording) Icons.Default.Stop else Icons.Default.Mic, "صوت", tint = if (isRecording) Red else Blue) }
                    OutlinedTextField(text, { if (it.length <= MAX_MESSAGE_LENGTH) text = it }, Modifier.weight(1f), enabled = !isBlocked, placeholder = { Text("اكتب رسالة") }, singleLine = true, colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Panel2, unfocusedContainerColor = Panel, focusedBorderColor = Pink, unfocusedBorderColor = Color(0xFF3A3355), focusedTextColor = TextMain, unfocusedTextColor = TextMain, cursorColor = Pink))
                    IconButton({ val v = text.trim(); if (v.isNotEmpty()) { sendMessage(v); text = "" } }, enabled = text.trim().isNotEmpty() && !isBlocked) { Icon(Icons.Default.Send, "إرسال", tint = Pink) }
                }
            }
        }
    }

    @Composable
    private fun MessageBubble(m: Msg) {
        val mine = m.senderId == uid
        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
            Column(horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                when (m.type) {
                    "image" -> AsyncImage(m.imageUrl, "صورة", Modifier.widthIn(max = 250.dp).heightIn(max = 280.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop)
                    "audio" -> OutlinedButton({ playAudio(m.audioUrl) }) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text("تشغيل التسجيل") }
                    else -> Surface(color = if (mine) Color(0xFF6D25D9) else Panel2, shape = RoundedCornerShape(18.dp)) { Text(m.text, color = TextMain, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) }
                }
                Text(formatTime(m.timestamp), color = TextMuted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
            }
        }
        Spacer(Modifier.height(5.dp))
    }

    @Composable
    private fun GenderChoice(value: String, onChange: (String) -> Unit) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GenderCard("male", "ذكر", value == "male", onChange, Modifier.weight(1f))
            GenderCard("female", "أنثى", value == "female", onChange, Modifier.weight(1f))
        }
    }

    @Composable
    private fun GenderCard(gender: String, label: String, selected: Boolean, onChange: (String) -> Unit, modifier: Modifier) {
        Column(modifier.clip(RoundedCornerShape(18.dp)).background(if (selected) Color(0xFF28104D) else Panel).border(1.dp, if (selected) (if (gender == "male") Blue else Pink) else Color(0xFF363052), RoundedCornerShape(18.dp)).clickable { onChange(gender) }.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            GenderAvatar(gender, Modifier.size(68.dp)); Spacer(Modifier.height(5.dp)); Text(label, color = if (selected) Color.White else TextMuted, fontWeight = FontWeight.Bold)
        }
    }

    @Composable
    private fun GenderAvatar(gender: String, modifier: Modifier) {
        val base = if (gender == "female") Pink else Blue
        Canvas(modifier.clip(CircleShape).background(base.copy(alpha = .18f))) {
            val w = size.width; val h = size.height
            drawCircle(base, radius = w * .23f, center = Offset(w / 2f, h * .34f))
            drawRoundRect(base, topLeft = Offset(w * .23f, h * .52f), size = androidx.compose.ui.geometry.Size(w * .54f, h * .34f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * .18f, w * .18f))
            if (gender == "female") {
                drawArc(Color(0xFF4A194D), 190f, 160f, false, style = Stroke(w * .16f, cap = StrokeCap.Round), topLeft = Offset(w * .17f, h * .08f), size = androidx.compose.ui.geometry.Size(w * .66f, h * .48f))
            } else {
                drawLine(Color(0xFF15335D), Offset(w * .31f, h * .19f), Offset(w * .69f, h * .19f), strokeWidth = w * .12f, cap = StrokeCap.Round)
            }
        }
    }

    @Composable
    private fun Avatar(name: String, verified: Boolean, url: String?, gender: String?, modifier: Modifier) {
        Box(modifier.clip(CircleShape).background(Color(0xFF26154B)), contentAlignment = Alignment.Center) {
            if (!url.isNullOrBlank()) AsyncImage(url, "صورة المستخدم", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else GenderAvatar(if (gender == "female") "female" else "male", Modifier.fillMaxSize())
            if (verified) Box(Modifier.align(Alignment.BottomEnd).size(19.dp).background(Blue, CircleShape).border(2.dp, Bg, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(13.dp)) }
        }
    }

    @Composable
    private fun VerifiedBadge() { Box(Modifier.padding(start = 4.dp).size(18.dp).background(Blue, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(12.dp)) } }

    @Composable
    private fun AdminBadge() { Surface(color = Color(0xFF35203F), shape = RoundedCornerShape(8.dp)) { Text("ADMIN", color = Color(0xFFFFC24B), fontSize = MaterialTheme.typography.labelSmall.fontSize, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) } }

    @Composable
    private fun ErrorText() { errorText?.let { Text(it, color = Red, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(10.dp)) } }

    private fun loadProfileOrSetup() {
        if (uid.isBlank()) return
        db.reference.child("users").child(uid).get().addOnSuccessListener { s ->
            val u = parseUser(s)
            profile = u
            if (u?.banned == true) { showError("هذا الحساب محظور من الإدارة"); logout(); return@addOnSuccessListener }
            if (u == null || u.name.isBlank() || u.gender.isBlank()) screen = "guest" else { screen = "main"; startListeners(); setPresence(true) }
        }.addOnFailureListener { showError(it.message ?: "تعذر تحميل الحساب") }
    }

    private fun createGuestProfile(name: String, gender: String) {
        loading = true; errorText = null
        if (uid.isBlank()) auth.signInAnonymously().addOnSuccessListener { uid = it.user!!.uid; saveProfile(name.trim(), "", gender, true) }.addOnFailureListener { loading = false; showError(it.message ?: "تعذر دخول الزائر") }
        else saveProfile(name.trim(), "", gender, true)
    }

    private fun register(name: String, email: String, password: String, gender: String) {
        loading = true; errorText = null
        val current = auth.currentUser
        val credential = EmailAuthProvider.getCredential(email.trim(), password)
        val task = if (current?.isAnonymous == true) current.linkWithCredential(credential) else auth.createUserWithEmailAndPassword(email.trim(), password)
        task.addOnSuccessListener { uid = it.user?.uid ?: uid; saveProfile(name.trim(), email.trim(), gender, false) }.addOnFailureListener { loading = false; showError(it.message ?: "تعذر إنشاء الحساب") }
    }

    private fun login(email: String, password: String) {
        loading = true; errorText = null
        auth.signInWithEmailAndPassword(email.trim(), password).addOnSuccessListener { uid = it.user!!.uid; loadProfileOrSetup() }.addOnFailureListener { loading = false; showError(it.message ?: "تعذر تسجيل الدخول") }
    }

    private fun resetPassword(email: String) {
        if (!email.contains("@")) { showError("اكتب البريد الإلكتروني أولًا"); return }
        auth.sendPasswordResetEmail(email.trim()).addOnSuccessListener { showError("تم إرسال رابط إعادة تعيين كلمة المرور") }.addOnFailureListener { showError(it.message ?: "تعذر إرسال الرابط") }
    }

    private fun saveProfile(name: String, email: String, gender: String, anonymous: Boolean) {
        val ref = db.reference.child("users").child(uid)
        ref.get().addOnSuccessListener { existing ->
            val old = parseUser(existing)
            val data = mutableMapOf<String, Any>(
                "uid" to uid, "name" to name, "email" to email,
                "gender" to (old?.gender?.takeIf { it.isNotBlank() } ?: gender),
                "verified" to (old?.verified ?: false),
                "admin" to isOwnerAccount(),
                "banned" to (old?.banned ?: false),
                "online" to true,
                "joinedAt" to (old?.joinedAt ?: ServerValue.TIMESTAMP),
                "lastSeen" to ServerValue.TIMESTAMP
            )
            ref.updateChildren(data).addOnSuccessListener {
                if (isOwnerAccount()) db.reference.child("users").child(uid).child("admin").setValue(true)
                setPresence(true)
                loading = false
                loadProfileOrSetup()
            }.addOnFailureListener { loading = false; showError(it.message ?: "تعذر حفظ البيانات") }
        }
    }

    private fun setPresence(isOnline: Boolean) {
        if (uid.isBlank()) return
        val ref = db.reference.child("users").child(uid)
        if (isOnline && connected && foreground) {
            ref.child("online").onDisconnect().setValue(false)
            ref.child("lastSeen").onDisconnect().setValue(ServerValue.TIMESTAMP)
            ref.updateChildren(mapOf(
                "online" to true,
                "joinedAt" to ServerValue.TIMESTAMP,
                "lastSeen" to ServerValue.TIMESTAMP
            ))
        } else {
            ref.updateChildren(mapOf("online" to false, "lastSeen" to ServerValue.TIMESTAMP))
        }
    }

    private fun startListeners() {
        usersListener?.let { db.reference.child("users").removeEventListener(it) }
        usersListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                onlineUsers.clear()
                s.children.mapNotNull { parseUser(it) }.forEach { if (it.online) onlineUsers.add(it) }
                parseUser(s.child(uid))?.let { profile = it }
            }
            override fun onCancelled(e: DatabaseError) { showError(e.message) }
        }
        db.reference.child("users").addValueEventListener(usersListener!!)

        chatsListener?.let { db.reference.child("userChats").child(uid).removeEventListener(it) }
        chatsListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                chats.clear()
                s.children.mapNotNull { snap -> ChatPreview(snap.key ?: return@mapNotNull null, snap.child("peerId").getValue(String::class.java).orEmpty(), snap.child("peerName").getValue(String::class.java).orEmpty(), snap.child("peerVerified").getValue(Boolean::class.java) ?: false, snap.child("peerAvatar").getValue(String::class.java).orEmpty(), snap.child("lastMessage").getValue(String::class.java).orEmpty(), snap.child("updatedAt").getValue(Long::class.java) ?: 0L) }.forEach { chats.add(it) }
            }
            override fun onCancelled(e: DatabaseError) { showError(e.message) }
        }
        db.reference.child("userChats").child(uid).addValueEventListener(chatsListener!!)
    }

    private fun startMatching() {
        if (uid.isBlank()) return
        loading = true; errorText = null
        val root = db.reference.child("waiting")
        val me = root.child(uid)
        me.onDisconnect().removeValue()
        root.runTransaction(object : Transaction.Handler {
            override fun doTransaction(d: MutableData): Transaction.Result {
                var peer: String? = null
                for (c in d.children) if (c.key != uid && c.child("roomId").value == null) { peer = c.key; break }
                if (peer == null) d.child(uid).value = mapOf("createdAt" to ServerValue.TIMESTAMP)
                else {
                    val p = peer!!; val roomId = listOf(uid, p).sorted().joinToString("-")
                    d.child(uid).value = mapOf("createdAt" to ServerValue.TIMESTAMP, "roomId" to roomId, "peerId" to p)
                    d.child(p).child("roomId").value = roomId; d.child(p).child("peerId").value = uid
                }
                return Transaction.success(d)
            }
            override fun onComplete(e: DatabaseError?, committed: Boolean, s: DataSnapshot?) {
                if (e != null || !committed) { loading = false; showError(e?.message ?: "تعذر البحث"); return }
                val meSnap = s?.child(uid); val room = meSnap?.child("roomId")?.getValue(String::class.java)
                if (!room.isNullOrBlank()) openRoom(room, meSnap.child("peerId").getValue(String::class.java).orEmpty()) else waitForMatch()
            }
        })
    }

    private fun waitForMatch() {
        val ref = db.reference.child("waiting").child(uid)
        waitingListener?.let { ref.removeEventListener(it) }
        waitingListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                val room = s.child("roomId").getValue(String::class.java)
                if (!room.isNullOrBlank()) { ref.removeValue(); waitingListener?.let { ref.removeEventListener(it) }; waitingListener = null; openRoom(room, s.child("peerId").getValue(String::class.java).orEmpty()) }
            }
            override fun onCancelled(e: DatabaseError) { loading = false; showError(e.message) }
        }
        ref.addValueEventListener(waitingListener!!)
    }

    private fun openRoom(roomId: String, peerId: String) {
        db.reference.child("waiting").child(uid).removeValue()
        currentRoomRef?.let { old -> messagesListener?.let { old.removeEventListener(it) } }
        currentRoom = roomId; messages.clear(); loading = false; screen = "chat"
        db.reference.child("users").child(peerId).get().addOnSuccessListener { currentPeer = parseUser(it); checkBlocked() }
        val ref = db.reference.child("rooms").child(roomId).child("messages")
        currentRoomRef = ref
        messagesListener = object : ChildEventListener {
            override fun onChildAdded(s: DataSnapshot, p: String?) {
                val type = s.child("type").getValue(String::class.java).orEmpty().ifBlank { "text" }
                val expires = s.child("expiresAt").getValue(Long::class.java) ?: 0L
                if (type == "image" && expires > 0 && expires <= System.currentTimeMillis()) {
                    val expiredId = s.key.orEmpty()
                    s.ref.removeValue()
                    if (expiredId.isNotBlank()) storage.reference.child("messages/$roomId/$expiredId.jpg").delete()
                    return
                }
                val m = Msg(s.key ?: return, s.child("senderId").getValue(String::class.java).orEmpty(), type, s.child("text").getValue(String::class.java).orEmpty(), s.child("imageUrl").getValue(String::class.java).orEmpty(), s.child("audioUrl").getValue(String::class.java).orEmpty(), s.child("timestamp").getValue(Long::class.java) ?: 0L, expires)
                if (messages.none { it.id == m.id }) messages.add(m)
                messages.sortBy { it.timestamp }
            }
            override fun onChildChanged(s: DataSnapshot, p: String?) {}
            override fun onChildRemoved(s: DataSnapshot) { messages.removeAll { it.id == s.key } }
            override fun onChildMoved(s: DataSnapshot, p: String?) {}
            override fun onCancelled(e: DatabaseError) { showError(e.message) }
        }
        ref.addChildEventListener(messagesListener!!)
        ref.orderByChild("expiresAt").addListenerForSingleValueEvent(object : ValueEventListener { override fun onDataChange(s: DataSnapshot) { s.children.forEach { val ex = it.child("expiresAt").getValue(Long::class.java) ?: 0L; if (ex > 0 && ex <= System.currentTimeMillis()) { val expiredId = it.key.orEmpty(); it.ref.removeValue(); if (expiredId.isNotBlank()) storage.reference.child("messages/$roomId/$expiredId.jpg").delete() } } }; override fun onCancelled(e: DatabaseError) {} })
        db.reference.child("rooms").child(roomId).child("members").updateChildren(mapOf(uid to true, peerId to true))
    }

    private fun checkBlocked() {
        val peer = currentPeer ?: return
        db.reference.child("blocks").child(uid).child(peer.uid).get().addOnSuccessListener { a -> db.reference.child("blocks").child(peer.uid).child(uid).get().addOnSuccessListener { b -> isBlocked = a.exists() || b.exists() } }
    }

    private fun sendMessage(text: String) {
        val room = currentRoom ?: return; val peer = currentPeer ?: return; if (isBlocked) return
        val ref = db.reference.child("rooms").child(room).child("messages").push()
        val data = mapOf<String, Any>("senderId" to uid, "type" to "text", "text" to text.take(MAX_MESSAGE_LENGTH), "timestamp" to ServerValue.TIMESTAMP, "expiresAt" to 0L)
        ref.setValue(data).addOnSuccessListener { updateChatPreview(peer, text) }.addOnFailureListener { showError(it.message ?: "فشل إرسال الرسالة") }
    }

    private fun updateChatPreview(peer: UserProfile, last: String) {
        val nowTs = System.currentTimeMillis()
        val mine = mapOf("peerId" to peer.uid, "peerName" to peer.name, "peerVerified" to peer.verified, "peerAvatar" to peer.avatarUrl, "lastMessage" to last, "updatedAt" to nowTs)
        val theirs = mapOf("peerId" to uid, "peerName" to (profile?.name ?: "مستخدم"), "peerVerified" to (profile?.verified ?: false), "peerAvatar" to (profile?.avatarUrl ?: ""), "lastMessage" to last, "updatedAt" to nowTs)
        currentRoom?.let { room -> db.reference.child("userChats").child(uid).child(room).setValue(mine); db.reference.child("userChats").child(peer.uid).child(room).setValue(theirs) }
    }

    private fun uploadChatImage(uri: Uri) {
        val room = currentRoom ?: return; val peer = currentPeer ?: return; if (isBlocked) return
        loading = true
        val id = UUID.randomUUID().toString()
        val storageRef = storage.reference.child("messages/$room/$id.jpg")
        storageRef.putFile(uri).continueWithTask { storageRef.downloadUrl }.addOnSuccessListener { url ->
            val expires = System.currentTimeMillis() + IMAGE_LIFETIME_MS
            val data = mapOf<String, Any>("senderId" to uid, "type" to "image", "text" to "", "imageUrl" to url.toString(), "timestamp" to ServerValue.TIMESTAMP, "expiresAt" to expires)
            db.reference.child("rooms").child(room).child("messages").child(id).setValue(data).addOnSuccessListener { loading = false; updateChatPreview(peer, "📷 صورة") }.addOnFailureListener { loading = false; showError(it.message ?: "فشل إرسال الصورة") }
        }.addOnFailureListener { loading = false; showError(it.message ?: "فشل رفع الصورة") }
    }

    private fun startRecording() {
        if (isRecording) return
        val file = File(cacheDir, "voice-${UUID.randomUUID()}.m4a")
        recordingFile = file
        try {
            mediaRecorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(file.absolutePath)
                prepare(); start()
            }
            isRecording = true
            Toast.makeText(this, "جاري التسجيل… اضغط الميكروفون مرة أخرى للإرسال", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { mediaRecorder?.release(); mediaRecorder = null; showError(e.message ?: "تعذر بدء التسجيل") }
    }

    private fun stopRecordingAndSend() {
        if (!isRecording) return
        try { mediaRecorder?.stop() } catch (_: Exception) {}
        mediaRecorder?.release(); mediaRecorder = null; isRecording = false
        val file = recordingFile ?: return; val room = currentRoom ?: return; val peer = currentPeer ?: return
        loading = true
        val id = UUID.randomUUID().toString(); val ref = storage.reference.child("messages/$room/$id.m4a")
        ref.putFile(Uri.fromFile(file)).continueWithTask { ref.downloadUrl }.addOnSuccessListener { url ->
            val data = mapOf<String, Any>("senderId" to uid, "type" to "audio", "text" to "", "audioUrl" to url.toString(), "timestamp" to ServerValue.TIMESTAMP, "expiresAt" to 0L)
            db.reference.child("rooms").child(room).child("messages").child(id).setValue(data).addOnSuccessListener { loading = false; updateChatPreview(peer, "🎤 تسجيل صوتي"); file.delete() }.addOnFailureListener { loading = false; showError(it.message ?: "فشل إرسال التسجيل") }
        }.addOnFailureListener { loading = false; showError(it.message ?: "فشل رفع التسجيل") }
    }

    private fun playAudio(url: String) {
        try { mediaPlayer?.release(); mediaPlayer = MediaPlayer().apply { setDataSource(url); setOnPreparedListener { it.start() }; setOnCompletionListener { it.release(); mediaPlayer = null }; prepareAsync() } } catch (e: Exception) { showError(e.message ?: "تعذر تشغيل التسجيل") }
    }

    private fun reportPeer() {
        val peer = currentPeer ?: return
        val reportId = db.reference.child("reports").push().key ?: return
        val data = mapOf<String, Any>(
            "reporterId" to uid,
            "targetId" to peer.uid,
            "roomId" to (currentRoom ?: ""),
            "reason" to "إبلاغ من داخل المحادثة",
            "createdAt" to ServerValue.TIMESTAMP
        )
        db.reference.child("reports").child(reportId).setValue(data)
            .addOnSuccessListener { showError("تم إرسال البلاغ للإدارة") }
            .addOnFailureListener { showError(it.message ?: "تعذر إرسال البلاغ") }
    }

    private fun blockPeer() {
        val peer = currentPeer ?: return
        db.reference.child("blocks").child(uid).child(peer.uid).setValue(true).addOnSuccessListener { isBlocked = true; closeRoom() }
    }

    private fun closeRoom() {
        waitingListener?.let { db.reference.child("waiting").child(uid).removeEventListener(it) }; waitingListener = null
        messagesListener?.let { currentRoomRef?.removeEventListener(it) }
        messagesListener = null; currentRoomRef = null; currentRoom = null; currentPeer = null; messages.clear(); isBlocked = false; isRecording = false; screen = "main"; selectedTab = 1
    }

    private fun saveName(name: String) { db.reference.child("users").child(uid).child("name").setValue(name.trim()).addOnSuccessListener { loadProfileOrSetup() }.addOnFailureListener { showError(it.message ?: "تعذر حفظ الاسم") } }

    private fun uploadPendingAvatar(uri: Uri) {
        val ref = storage.reference.child("pendingAvatars/$uid-${UUID.randomUUID()}.jpg")
        loading = true
        ref.putFile(uri).continueWithTask { ref.downloadUrl }.addOnSuccessListener { url -> db.reference.child("users").child(uid).updateChildren(mapOf("avatarPendingUrl" to url.toString(), "avatarPending" to true)).addOnSuccessListener { loading = false; loadProfileOrSetup() } }.addOnFailureListener { loading = false; showError(it.message ?: "تعذر رفع الصورة") }
    }

    private fun approveAvatar(u: UserProfile) { db.reference.child("users").child(u.uid).updateChildren(mapOf("avatarUrl" to u.avatarPendingUrl, "avatarPending" to false, "avatarPendingUrl" to "")).addOnFailureListener { showError(it.message ?: "تعذر قبول الصورة") } }
    private fun rejectAvatar(u: UserProfile) { db.reference.child("users").child(u.uid).updateChildren(mapOf("avatarPending" to false, "avatarPendingUrl" to "")).addOnFailureListener { showError(it.message ?: "تعذر رفض الصورة") } }
    private fun setVerified(targetUid: String, value: Boolean) { db.reference.child("users").child(targetUid).child("verified").setValue(value) }
    private fun setBanned(targetUid: String, value: Boolean) { db.reference.child("users").child(targetUid).child("banned").setValue(value).addOnSuccessListener { if (value) db.reference.child("users").child(targetUid).child("online").setValue(false) } }
    private fun deleteUserData(u: UserProfile) {
        if (u.uid == uid || u.admin) return
        db.reference.child("users").child(u.uid).removeValue()
        db.reference.child("userChats").child(u.uid).removeValue()
        db.reference.child("blocks").child(u.uid).removeValue()
    }

    private fun logout() {
        setPresence(false); cleanup(); auth.signOut(); uid = ""; profile = null; screen = "login"; selectedTab = 0
    }

    private fun parseUser(s: DataSnapshot): UserProfile? {
        if (!s.exists()) return null
        return UserProfile(
            uid = s.key ?: s.child("uid").getValue(String::class.java).orEmpty(),
            name = s.child("name").getValue(String::class.java).orEmpty(),
            email = s.child("email").getValue(String::class.java).orEmpty(),
            gender = s.child("gender").getValue(String::class.java).orEmpty(),
            avatarUrl = s.child("avatarUrl").getValue(String::class.java).orEmpty(),
            avatarPendingUrl = s.child("avatarPendingUrl").getValue(String::class.java).orEmpty(),
            avatarPending = s.child("avatarPending").getValue(Boolean::class.java) ?: false,
            verified = s.child("verified").getValue(Boolean::class.java) ?: false,
            admin = s.child("email").getValue(String::class.java).orEmpty().equals(OWNER_EMAIL, ignoreCase = true),
            banned = s.child("banned").getValue(Boolean::class.java) ?: false,
            online = s.child("online").getValue(Boolean::class.java) ?: false,
            joinedAt = s.child("joinedAt").getValue(Long::class.java) ?: 0L,
            lastSeen = s.child("lastSeen").getValue(Long::class.java) ?: 0L
        )
    }

    private fun cleanup() {
        usersListener?.let { db.reference.child("users").removeEventListener(it) }
        chatsListener?.let { db.reference.child("userChats").child(uid).removeEventListener(it) }
        messagesListener?.let { currentRoomRef?.removeEventListener(it) }
        waitingListener?.let { db.reference.child("waiting").child(uid).removeEventListener(it) }
        usersListener = null; chatsListener = null; messagesListener = null; currentRoomRef = null; waitingListener = null
        onlineUsers.clear(); chats.clear(); messages.clear()
    }

    private fun showError(msg: String) { errorText = msg; Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    private fun formatTime(ts: Long): String { if (ts <= 0) return ""; val d = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()); return d.format(java.util.Date(ts)) }
}

@Composable
private fun DardashaTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(primary = Pink, secondary = Purple, tertiary = Blue, background = Bg, surface = Panel, onBackground = TextMain, onSurface = TextMain)
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
